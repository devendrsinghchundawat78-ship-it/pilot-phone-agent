package app.pilot.agent;

import android.content.Context;
import android.graphics.Bitmap;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

/** Minimal client for Gemini and OpenAI-compatible (Groq, OpenRouter, ...) chat APIs. */
final class Llm {
    static class LlmException extends Exception {
        final int code;
        LlmException(int code, String msg) { super(msg); this.code = code; }
    }

    static String ask(Context c, String system, String user) throws Exception {
        return ask(c, system, user, null);
    }

    static String ask(Context c, String system, String user, Bitmap shot) throws Exception {
        String key = Store.getKey(c);
        if (key.isEmpty()) throw new LlmException(0, "No AI key saved. Add it in Settings.");
        String model = Store.model(c);
        for (int attempt = 0; ; attempt++) {
            try {
                if (Store.GEMINI.equals(Store.provider(c))) return gemini(key, model, system, user, shot);
                return openai(Store.baseUrl(c), key, model, system, user);
            } catch (LlmException e) {
                boolean retry = (e.code == 429 || e.code >= 500) && attempt < 3;
                if (!retry) throw e;
                Runner.say(Runner.NOTE, "AI is busy, trying again in a few seconds...");
                Thread.sleep(6000L * (attempt + 1));
            }
        }
    }

    private static String gemini(String key, String model, String system, String user, Bitmap shot) throws Exception {
        JSONObject body = new JSONObject();
        body.put("systemInstruction", new JSONObject().put("parts", new JSONArray().put(new JSONObject().put("text", system))));
        JSONArray userParts = new JSONArray().put(new JSONObject().put("text", user));
        if (shot != null) {
            java.io.ByteArrayOutputStream bos = new java.io.ByteArrayOutputStream();
            shot.compress(Bitmap.CompressFormat.JPEG, 60, bos);
            userParts.put(new JSONObject().put("inline_data", new JSONObject()
                    .put("mime_type", "image/jpeg")
                    .put("data", android.util.Base64.encodeToString(bos.toByteArray(), android.util.Base64.NO_WRAP))));
        }
        body.put("contents", new JSONArray().put(new JSONObject()
                .put("role", "user")
                .put("parts", userParts)));
        body.put("generationConfig", new JSONObject()
                .put("temperature", 0.2)
                .put("responseMimeType", "application/json"));
        String url = "https://generativelanguage.googleapis.com/v1beta/models/" + model + ":generateContent";
        String res = post(url, body.toString(), "x-goog-api-key", key);
        JSONObject j = new JSONObject(res);
        JSONArray cands = j.optJSONArray("candidates");
        if (cands == null || cands.length() == 0) throw new LlmException(200, "AI gave an empty answer.");
        JSONArray parts = cands.getJSONObject(0).getJSONObject("content").getJSONArray("parts");
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < parts.length(); i++) {
            JSONObject part = parts.getJSONObject(i);
            if (part.optBoolean("thought", false)) continue;
            sb.append(part.optString("text", ""));
        }
        return sb.toString();
    }

    private static String openai(String base, String key, String model, String system, String user) throws Exception {
        JSONObject body = new JSONObject();
        body.put("model", model);
        body.put("temperature", 0.2);
        body.put("response_format", new JSONObject().put("type", "json_object"));
        body.put("messages", new JSONArray()
                .put(new JSONObject().put("role", "system").put("content", system))
                .put(new JSONObject().put("role", "user").put("content", user)));
        String b = base.endsWith("/") ? base.substring(0, base.length() - 1) : base;
        String res = post(b + "/chat/completions", body.toString(), "Authorization", "Bearer " + key);
        JSONObject j = new JSONObject(res);
        return j.getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content");
    }

    private static String post(String url, String json, String hdr, String val) throws Exception {
        HttpURLConnection h = (HttpURLConnection) new URL(url).openConnection();
        h.setRequestMethod("POST");
        h.setConnectTimeout(20000);
        h.setReadTimeout(90000);
        h.setDoOutput(true);
        h.setRequestProperty("Content-Type", "application/json");
        h.setRequestProperty(hdr, val);
        try (OutputStream os = h.getOutputStream()) {
            os.write(json.getBytes(StandardCharsets.UTF_8));
        }
        int code = h.getResponseCode();
        InputStream is = code >= 400 ? h.getErrorStream() : h.getInputStream();
        StringBuilder sb = new StringBuilder();
        if (is != null) {
            try (BufferedReader r = new BufferedReader(new InputStreamReader(is, StandardCharsets.UTF_8))) {
                String line;
                while ((line = r.readLine()) != null) sb.append(line).append('\n');
            }
        }
        if (code >= 400) {
            String msg;
            if (code == 401 || code == 403) msg = "The AI key was rejected. Check it in Settings.";
            else if (code == 429) msg = "AI free limit reached for now.";
            else if (code == 404) msg = "AI model name not found. Check the model in Settings.";
            else msg = "AI error " + code;
            throw new LlmException(code, msg);
        }
        return sb.toString();
    }
}
