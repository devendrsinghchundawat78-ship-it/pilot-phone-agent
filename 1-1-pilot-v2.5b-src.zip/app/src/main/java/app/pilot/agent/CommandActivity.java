package app.pilot.agent;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * Floating command panel shown over any app as a translucent activity.
 * Activities get the real keyboard on every device, so this is the reliable
 * "type or speak a task without opening the app" surface. Closes after send.
 * Follows the saved theme; the glass theme renders the panel frosted.
 */
public class CommandActivity extends Activity {
    private static final int REQ_MIC = 3;

    private Theme th;
    private MascotView mascot;
    private EditText input;
    private ImageView mic;
    private TextView send;
    private TextView status;
    private SpeechRecognizer sr;
    private boolean listening;

    private final Runner.Listener listener = this::refresh;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        th = Theme.get(this);
        WindowManager.LayoutParams wl = getWindow().getAttributes();
        wl.gravity = Gravity.TOP | Gravity.CENTER_HORIZONTAL;
        wl.y = dp(96);
        wl.width = getResources().getDisplayMetrics().widthPixels - dp(20);
        if (th.glass && Build.VERSION.SDK_INT >= 31) {
            wl.flags |= WindowManager.LayoutParams.FLAG_BLUR_BEHIND;
            wl.setBlurBehindRadius(dp(14));
        }
        getWindow().setAttributes(wl);
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE);
        setFinishOnTouchOutside(true);
        build();
    }

    @Override protected void onResume() {
        super.onResume();
        Runner.addListener(listener);
        refresh();
        if (input != null) {
            input.postDelayed(() -> {
                input.requestFocus();
                InputMethodManager im = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
                im.showSoftInput(input, InputMethodManager.SHOW_IMPLICIT);
            }, 150);
        }
    }

    @Override protected void onPause() {
        super.onPause();
        Runner.removeListener(listener);
    }

    @Override protected void onDestroy() {
        stopVoice();
        super.onDestroy();
    }

    private GradientDrawable cardBg() {
        if (th.glass) {
            GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                    new int[]{Theme.GLASS_TOP, Theme.GLASS_BOTTOM});
            g.setCornerRadius(dp(22));
            g.setStroke(dp(1), Theme.GLASS_STROKE);
            return g;
        }
        return round(th.bg, 22, th.stroke);
    }

    private GradientDrawable fieldBg() {
        if (th.glass) return round(Theme.GLASS_FIELD, 20, 0x22FFFFFF);
        return round(th.surface2, 20, th.stroke);
    }

    private void build() {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(14), dp(12), dp(14), dp(14));
        card.setBackground(cardBg());

        LinearLayout head = new LinearLayout(this);
        head.setGravity(Gravity.CENTER_VERTICAL);
        mascot = new MascotView(this);
        if (Theme.PORCELAIN.equals(th.id)) mascot.setColors(th.text, th.bg);
        LinearLayout.LayoutParams mlp = new LinearLayout.LayoutParams(dp(30), dp(30));
        mlp.rightMargin = dp(8);
        head.addView(mascot, mlp);
        TextView title = new TextView(this);
        title.setText("Pilot");
        title.setTextColor(th.text);
        title.setTextSize(14);
        title.setTypeface(null, Typeface.BOLD);
        head.addView(title, new LinearLayout.LayoutParams(0, -2, 1f));
        TextView hist = new TextView(this);
        hist.setText("History");
        hist.setTextColor(th.muted);
        hist.setTextSize(12);
        hist.setPadding(dp(8), dp(4), dp(8), dp(4));
        hist.setOnClickListener(v -> {
            try { startActivity(new Intent(this, HistoryActivity.class)); } catch (Throwable ignored) { }
        });
        head.addView(hist);
        TextView close = new TextView(this);
        close.setText("\u2715");
        close.setTextColor(th.muted);
        close.setTextSize(16);
        close.setPadding(dp(10), 0, dp(4), 0);
        close.setOnClickListener(v -> finish());
        head.addView(close);
        card.addView(head);

        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);

        input = new EditText(this);
        input.setHint("Type or speak a task");
        input.setHintTextColor(th.muted);
        input.setTextColor(th.text);
        input.setTextSize(15);
        input.setSingleLine(true);
        input.setImeOptions(EditorInfo.IME_ACTION_SEND);
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        input.setPadding(dp(14), 0, dp(14), 0);
        input.setBackground(fieldBg());
        input.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_SEND
                    || (event != null && event.getKeyCode() == android.view.KeyEvent.KEYCODE_ENTER)) {
                send();
                return true;
            }
            return false;
        });
        row.addView(input, new LinearLayout.LayoutParams(0, dp(44), 1f));

        mic = new ImageView(this);
        mic.setImageResource(R.drawable.ic_mic);
        mic.setColorFilter(th.text);
        mic.setScaleType(ImageView.ScaleType.CENTER);
        mic.setBackground(oval(th.glass ? Theme.GLASS_FIELD : th.surface2));
        mic.setContentDescription("Speak");
        mic.setOnClickListener(v -> onMic());
        LinearLayout.LayoutParams ml = new LinearLayout.LayoutParams(dp(44), dp(44));
        ml.leftMargin = dp(8);
        row.addView(mic, ml);

        send = new TextView(this);
        send.setGravity(Gravity.CENTER);
        send.setTypeface(null, Typeface.BOLD);
        send.setOnClickListener(v -> send());
        LinearLayout.LayoutParams sl = new LinearLayout.LayoutParams(dp(44), dp(44));
        sl.leftMargin = dp(8);
        row.addView(send, sl);

        LinearLayout.LayoutParams rl = new LinearLayout.LayoutParams(-1, -2);
        rl.topMargin = dp(10);
        card.addView(row, rl);

        status = new TextView(this);
        status.setTextColor(th.muted);
        status.setTextSize(12);
        status.setMaxLines(2);
        status.setPadding(dp(4), dp(8), dp(4), 0);
        card.addView(status);

        setContentView(card);
    }

    private void send() {
        if (Runner.running) { Runner.stop(); return; }
        String goal = input.getText().toString().trim();
        if (goal.isEmpty()) { finish(); return; }
        boolean test = goal.equals("/selftest");
        if (!test && !Store.hasKey(this)) {
            status.setText("Add your free AI key in the app first");
            try {
                Intent i = new Intent(this, MainActivity.class);
                i.putExtra("open_settings", true);
                startActivity(i);
            } catch (Throwable ignored) { }
            finish();
            return;
        }
        if (test) Runner.selfTest(this); else Runner.start(this, goal);
        finish();
    }

    private void onMic() {
        if (listening) {
            stopVoice();
            status.setText("Stopped listening");
            refresh();
            return;
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_MIC);
            return;
        }
        startVoice();
    }

    @Override public void onRequestPermissionsResult(int code, String[] perms, int[] grants) {
        super.onRequestPermissionsResult(code, perms, grants);
        if (code == REQ_MIC && grants.length > 0 && grants[0] == PackageManager.PERMISSION_GRANTED) startVoice();
        else if (code == REQ_MIC) status.setText("Microphone not allowed. You can still type.");
    }

    private void startVoice() {
        stopVoice();
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            status.setText("Voice typing is not available on this phone");
            return;
        }
        try {
            sr = SpeechRecognizer.createSpeechRecognizer(this);
        } catch (Throwable t) {
            status.setText("Voice typing is not available on this phone");
            return;
        }
        sr.setRecognitionListener(new RecognitionListener() {
            @Override public void onReadyForSpeech(Bundle params) {
                listening = true;
                status.setText("Listening...");
                refresh();
            }
            @Override public void onBeginningOfSpeech() { }
            @Override public void onRmsChanged(float rmsdB) { }
            @Override public void onBufferReceived(byte[] buffer) { }
            @Override public void onEndOfSpeech() {
                listening = false;
                refresh();
            }
            @Override public void onError(int error) {
                listening = false;
                if (error == 7) stopVoice();
                status.setText((error == 6 || error == 7
                        ? "Did not catch that"
                        : "Voice did not work") + " (" + error + "). Tap the mic and try again");
                refresh();
            }
            @Override public void onResults(Bundle results) {
                listening = false;
                ArrayList<String> out = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                if (out != null && !out.isEmpty() && !out.get(0).trim().isEmpty()) {
                    input.setText(out.get(0).trim());
                    input.setSelection(input.getText().length());
                    send();
                } else {
                    refresh();
                }
            }
            @Override public void onPartialResults(Bundle partialResults) {
                ArrayList<String> out = partialResults.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                if (out != null && !out.isEmpty() && input != null) {
                    input.setText(out.get(0));
                    input.setSelection(input.getText().length());
                }
            }
            @Override public void onEvent(int eventType, Bundle params) { }
        });
        Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "hi-IN")
                .putExtra(RecognizerIntent.EXTRA_ONLY_RETURN_LANGUAGE_PREFERENCE, "hi-IN")
                .putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                .putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1);
        try {
            sr.startListening(i);
            listening = true;
            status.setText("Listening...");
        } catch (Throwable t) {
            status.setText("Voice did not work. Try again");
        }
        refresh();
    }

    private void stopVoice() {
        if (sr != null) {
            try { sr.stopListening(); } catch (Throwable ignored) { }
            try { sr.destroy(); } catch (Throwable ignored) { }
            sr = null;
        }
        listening = false;
    }

    private void refresh() {
        boolean run = Runner.running;
        if (mascot != null) mascot.setState(run ? MascotView.WORKING : MascotView.IDLE);
        if (send != null) {
            if (run) {
                send.setText("\u25A0");
                send.setTextSize(13);
                send.setTextColor(th.text);
                send.setBackground(oval(th.glass ? Theme.GLASS_FIELD : th.surface2));
                send.setContentDescription("Stop");
            } else {
                send.setText("\u2191");
                send.setTextSize(18);
                send.setTextColor(th.dark);
                send.setBackground(oval(th.text));
                send.setContentDescription("Send");
            }
        }
        if (mic != null) mic.setColorFilter(listening ? th.warn : th.text);
        if (status != null && status.getText().length() == 0) {
            status.setText(run ? "Working..." : "");
        }
    }

    private GradientDrawable round(int fill, int radiusDp, int stroke) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(fill);
        g.setCornerRadius(dp(radiusDp));
        g.setStroke(dp(1), stroke);
        return g;
    }

    private GradientDrawable oval(int fill) {
        GradientDrawable g = new GradientDrawable();
        g.setShape(GradientDrawable.OVAL);
        g.setColor(fill);
        return g;
    }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }
}
