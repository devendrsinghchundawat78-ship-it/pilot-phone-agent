package app.pilot.agent;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/** Saved past tasks: goal, outcome and transcript. Stays on the phone only. */
final class History {
    static final class Item {
        long ts;
        String goal = "";
        String status = "";
        String message = "";
        int steps;
        final List<String> transcript = new ArrayList<>();
    }

    private static final int CAP = 50;
    private static final int MAX_LINES = 60;

    private static SharedPreferences p(Context c) {
        return c.getApplicationContext().getSharedPreferences("pilot_history", Context.MODE_PRIVATE);
    }

    static synchronized List<Item> list(Context c) {
        List<Item> out = new ArrayList<>();
        try {
            JSONArray a = new JSONArray(p(c).getString("items", "[]"));
            for (int i = 0; i < a.length(); i++) {
                JSONObject o = a.getJSONObject(i);
                Item it = new Item();
                it.ts = o.optLong("ts");
                it.goal = o.optString("goal");
                it.status = o.optString("status");
                it.message = o.optString("message");
                it.steps = o.optInt("steps");
                JSONArray tr = o.optJSONArray("transcript");
                if (tr != null) for (int j = 0; j < tr.length(); j++) it.transcript.add(tr.optString(j));
                out.add(it);
            }
        } catch (Exception ignored) { }
        return out;
    }

    static synchronized void add(Context c, String goal, String status, String message, int steps, List<String> transcript) {
        try {
            List<Item> all = list(c);
            Item it = new Item();
            it.ts = System.currentTimeMillis();
            it.goal = goal == null ? "" : goal;
            it.status = status == null ? "" : status;
            it.message = message == null ? "" : message;
            it.steps = steps;
            if (transcript != null) {
                int from = Math.max(0, transcript.size() - MAX_LINES);
                for (int i = from; i < transcript.size(); i++) it.transcript.add(transcript.get(i));
            }
            all.add(0, it);
            while (all.size() > CAP) all.remove(all.size() - 1);
            JSONArray a = new JSONArray();
            for (Item x : all) {
                JSONObject o = new JSONObject();
                o.put("ts", x.ts);
                o.put("goal", x.goal);
                o.put("status", x.status);
                o.put("message", x.message);
                o.put("steps", x.steps);
                JSONArray tr = new JSONArray();
                for (String line : x.transcript) tr.put(line);
                o.put("transcript", tr);
                a.put(o);
            }
            p(c).edit().putString("items", a.toString()).apply();
        } catch (Exception ignored) { }
    }

    static synchronized void clear(Context c) {
        p(c).edit().putString("items", "[]").apply();
    }
}
