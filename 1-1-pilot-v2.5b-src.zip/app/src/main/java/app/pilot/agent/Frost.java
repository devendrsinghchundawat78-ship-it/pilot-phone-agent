package app.pilot.agent;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.view.Display;
import android.view.View;

import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

/**
 * Real frosted glass that does not depend on the phone's system blur:
 * grabs a screenshot through the accessibility API, crops the area under
 * our floating view, softens it hard (pyramid downscale), and hands back a
 * bitmap the view draws under its tint. Works on any Android 10+ phone.
 */
final class Frost {
    interface Sink { void accept(Bitmap b); }

    /** Async: captures the screen region under view v, blurred, delivered on the main thread. */
    static void capture(final AgentService svc, final View v, final Sink sink) {
        if (Build.VERSION.SDK_INT < 30 || svc == null || v == null || !v.isShown()) {
            new Handler(Looper.getMainLooper()).post(() -> sink.accept(null));
            return;
        }
        final int[] loc = new int[2];
        v.getLocationOnScreen(loc);
        final int vw = v.getWidth(), vh = v.getHeight();
        if (vw <= 0 || vh <= 0) {
            new Handler(Looper.getMainLooper()).post(() -> sink.accept(null));
            return;
        }
        final CountDownLatch l = new CountDownLatch(1);
        final Bitmap[] out = {null};
        try {
            svc.takeScreenshot(Display.DEFAULT_DISPLAY, svc.getMainExecutor(),
                    new android.accessibilityservice.AccessibilityService.TakeScreenshotCallback() {
                        @Override public void onSuccess(android.accessibilityservice.AccessibilityService.ScreenshotResult r) {
                            try {
                                Bitmap hw = Bitmap.wrapHardwareBuffer(r.getHardwareBuffer(), r.getColorSpace());
                                if (hw != null) out[0] = hw.copy(Bitmap.Config.ARGB_8888, false);
                            } catch (Throwable ignored) { }
                            l.countDown();
                        }
                        @Override public void onFailure(int errorCode) { l.countDown(); }
                    });
        } catch (Throwable t) {
            new Handler(Looper.getMainLooper()).post(() -> sink.accept(null));
            return;
        }
        new Thread(() -> {
            Bitmap res = null;
            try {
                l.await(4, TimeUnit.SECONDS);
                Bitmap full = out[0];
                if (full != null) {
                    int x = Math.max(0, loc[0]), y = Math.max(0, loc[1]);
                    int w = Math.min(vw, full.getWidth() - x), hgt = Math.min(vh, full.getHeight() - y);
                    if (w > 8 && hgt > 8) {
                        Bitmap crop = Bitmap.createBitmap(full, x, y, w, hgt);
                        res = soften(crop);
                    }
                }
            } catch (Throwable ignored) { }
            final Bitmap done = res;
            new Handler(Looper.getMainLooper()).post(() -> sink.accept(done));
        }).start();
    }

    /** Heavy soft blur via progressive downscale; returns a small smooth bitmap. */
    private static Bitmap soften(Bitmap src) {
        int w = Math.max(12, src.getWidth() / 7);
        int h = Math.max(12, src.getHeight() / 7);
        Bitmap small = Bitmap.createScaledBitmap(src, w, h, true);
        // extra 3x3 box pass to kill blockiness
        Bitmap pass = small.copy(Bitmap.Config.ARGB_8888, true);
        int[] px = new int[w * h];
        small.getPixels(px, 0, w, 0, 0, w, h);
        int[] outPx = new int[w * h];
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                int r = 0, g = 0, b = 0, n = 0;
                for (int dy = -1; dy <= 1; dy++) {
                    for (int dx = -1; dx <= 1; dx++) {
                        int xx = x + dx, yy = y + dy;
                        if (xx < 0 || yy < 0 || xx >= w || yy >= h) continue;
                        int c = px[yy * w + xx];
                        r += (c >> 16) & 0xFF; g += (c >> 8) & 0xFF; b += c & 0xFF; n++;
                    }
                }
                outPx[y * w + x] = 0xFF000000 | ((r / n) << 16) | ((g / n) << 8) | (b / n);
            }
        }
        pass.setPixels(outPx, 0, w, 0, 0, w, h);
        return pass;
    }

    /** Blocking full screenshot for the vision fallback (called from the Runner thread). */
    static Bitmap shot(AgentService svc) {
        if (Build.VERSION.SDK_INT < 30 || svc == null) return null;
        final CountDownLatch l = new CountDownLatch(1);
        final Bitmap[] out = {null};
        try {
            svc.takeScreenshot(Display.DEFAULT_DISPLAY, svc.getMainExecutor(),
                    new android.accessibilityservice.AccessibilityService.TakeScreenshotCallback() {
                        @Override public void onSuccess(android.accessibilityservice.AccessibilityService.ScreenshotResult r) {
                            try {
                                Bitmap hw = Bitmap.wrapHardwareBuffer(r.getHardwareBuffer(), r.getColorSpace());
                                if (hw != null) out[0] = hw.copy(Bitmap.Config.ARGB_8888, false);
                            } catch (Throwable ignored) { }
                            l.countDown();
                        }
                        @Override public void onFailure(int errorCode) { l.countDown(); }
                    });
            l.await(4, TimeUnit.SECONDS);
        } catch (Throwable ignored) { }
        return out[0];
    }

    private Frost() { }
}
