package app.pilot.agent;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.provider.Settings;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {
    private static final int REQ_MIC = 7;

    private Theme th;
    private FrameLayout host;
    private boolean inSettings = false;
    private final Runner.Listener refreshListener = this::refresh;

    // home views
    private LinearLayout statusCard, chat;
    private ScrollView scroll;
    private EditText input;
    private TextView sendBtn;
    private LinearLayout chips;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        th = Theme.get(this);
        host = new FrameLayout(this);
        host.setBackgroundColor(th.bg);
        getWindow().getDecorView().setBackgroundColor(th.bg);
        setContentView(host);
        showHome();
        if (getIntent().getBooleanExtra("request_mic", false)) maybeAskMic();
        if (getIntent().getBooleanExtra("open_settings", false)) showSettings();
    }

    @Override protected void onNewIntent(android.content.Intent i) {
        super.onNewIntent(i);
        setIntent(i);
        if (i.getBooleanExtra("request_mic", false)) maybeAskMic();
        if (i.getBooleanExtra("open_settings", false)) showSettings();
    }

    private boolean micGranted() {
        return checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED;
    }

    private void maybeAskMic() {
        if (!micGranted()) requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_MIC);
    }

    @Override public void onRequestPermissionsResult(int code, String[] perms, int[] grants) {
        super.onRequestPermissionsResult(code, perms, grants);
        refresh();
    }

    @Override protected void onResume() {
        super.onResume();
        Theme now = Theme.get(this);
        if (now != th) { th = now; host.setBackgroundColor(th.bg); if (inSettings) showSettings(); else showHome(); }
        Runner.addListener(refreshListener);
        refresh();
    }

    @Override protected void onPause() {
        super.onPause();
        Runner.removeListener(refreshListener);
    }

    @Override public void onBackPressed() {
        if (inSettings) showHome(); else super.onBackPressed();
    }

    // ---------------- home ----------------

    private void showHome() {
        inSettings = false;
        host.removeAllViews();
        host.setBackgroundColor(th.bg);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(44), dp(20), dp(14));

        LinearLayout head = new LinearLayout(this);
        head.setOrientation(LinearLayout.HORIZONTAL);
        head.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout titles = new LinearLayout(this);
        titles.setOrientation(LinearLayout.VERTICAL);
        titles.addView(text("Pilot", 28, th.text, true));
        titles.addView(text("Tell me what to do on your phone", 13, th.muted, false));
        head.addView(titles, new LinearLayout.LayoutParams(0, -2, 1f));
        TextView hist = pill("History", false);
        hist.setOnClickListener(v -> startActivity(new Intent(this, HistoryActivity.class)));
        head.addView(hist);
        TextView gap = new TextView(this);
        head.addView(gap, new LinearLayout.LayoutParams(dp(8), 1));
        TextView set = pill("Settings", false);
        set.setOnClickListener(v -> showSettings());
        head.addView(set);
        root.addView(head);

        statusCard = new LinearLayout(this);
        statusCard.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams sl = new LinearLayout.LayoutParams(-1, -2);
        sl.topMargin = dp(18);
        root.addView(statusCard, sl);

        scroll = new ScrollView(this);
        scroll.setVerticalScrollBarEnabled(false);
        chat = new LinearLayout(this);
        chat.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(chat, new ViewGroup.LayoutParams(-1, -2));
        LinearLayout.LayoutParams cl = new LinearLayout.LayoutParams(-1, 0, 1f);
        cl.topMargin = dp(8);
        root.addView(scroll, cl);

        chips = new LinearLayout(this);
        chips.setOrientation(LinearLayout.VERTICAL);
        root.addView(chips, new LinearLayout.LayoutParams(-1, -2));

        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        input = new EditText(this);
        input.setHint("What should I do?");
        input.setHintTextColor(th.muted);
        input.setTextColor(th.text);
        input.setTextSize(15);
        input.setMaxLines(4);
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        input.setPadding(dp(18), dp(12), dp(18), dp(12));
        input.setBackground(round(th.surface, 26, th.stroke));
        bar.addView(input, new LinearLayout.LayoutParams(0, -2, 1f));
        sendBtn = new TextView(this);
        sendBtn.setGravity(Gravity.CENTER);
        sendBtn.setTextSize(20);
        sendBtn.setTypeface(null, Typeface.BOLD);
        sendBtn.setOnClickListener(v -> onSend());
        LinearLayout.LayoutParams bl = new LinearLayout.LayoutParams(dp(48), dp(48));
        bl.leftMargin = dp(10);
        bar.addView(sendBtn, bl);
        LinearLayout.LayoutParams barl = new LinearLayout.LayoutParams(-1, -2);
        barl.topMargin = dp(10);
        root.addView(bar, barl);

        host.addView(root, new FrameLayout.LayoutParams(-1, -1));
        refresh();
    }

    private void refresh() {
        if (inSettings || statusCard == null) return;
        boolean acc = AgentService.inst != null;
        boolean key = Store.hasKey(this);
        boolean run = Runner.running;

        // status card
        statusCard.removeAllViews();
        if (acc && key) {
            LinearLayout row = new LinearLayout(this);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.addView(dot(run ? th.warn : th.ok), new LinearLayout.LayoutParams(dp(8), dp(8)));
            TextView t = text(run ? "Working on it..." : "Ready", 13, th.muted, false);
            t.setPadding(dp(8), 0, 0, 0);
            row.addView(t);
            statusCard.addView(row);
            if (Store.islandOn(this)) {
                TextView tip = text("Tip: tap the small Pilot pill at the top of any screen to type or speak a task.", 12, th.muted, false);
                tip.setPadding(0, dp(6), 0, 0);
                statusCard.addView(tip);
            }
        } else {
            LinearLayout card = new LinearLayout(this);
            card.setOrientation(LinearLayout.VERTICAL);
            card.setPadding(dp(16), dp(14), dp(16), dp(14));
            card.setBackground(round(th.surface, 20, th.stroke));
            card.addView(text("Two quick steps to start", 15, th.text, true));
            card.addView(setupRow("Allow screen control", acc, "Turn on", v ->
                    startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))));
            card.addView(setupRow("Add your free AI key", key, "Add", v -> showSettings()));
            if (acc && key) card.addView(setupRow("Allow microphone (voice commands)", micGranted(), "Allow", v -> maybeAskMic()));
            if (!acc) {
                TextView hint = text("In Accessibility, open Pilot and switch it on. If Android says it is restricted: "
                        + "Settings > Apps > Pilot > three dots > Allow restricted settings, then try again.", 12, th.muted, false);
                hint.setPadding(0, dp(8), 0, 0);
                card.addView(hint);
            }
            statusCard.addView(card);
        }

        // chat
        chat.removeAllViews();
        List<Runner.Entry> copy;
        synchronized (Runner.log) { copy = new ArrayList<>(Runner.log); }
        for (Runner.Entry e : copy) chat.addView(bubble(e));
        chips.removeAllViews();
        if (copy.isEmpty() && acc && key) {
            chips.addView(text("Try", 12, th.muted, false));
            chips.addView(chip("Open YouTube and search for lo-fi music"));
            chips.addView(chip("Set an alarm for 6:30 am"));
            chips.addView(chip("Check my battery usage in Settings"));
        }
        scroll.post(() -> scroll.fullScroll(View.FOCUS_DOWN));

        // send button
        if (run) {
            sendBtn.setText("\u25A0");
            sendBtn.setTextSize(16);
            sendBtn.setTextColor(th.text);
            sendBtn.setBackground(oval(th.surface2));
        } else {
            sendBtn.setText("\u2191");
            sendBtn.setTextSize(20);
            sendBtn.setTextColor(th.dark);
            sendBtn.setBackground(oval(th.text));
        }
    }

    private void onSend() {
        if (Runner.running) { Runner.stop(); return; }
        String goal = input.getText().toString().trim();
        if (goal.isEmpty()) return;
        boolean test = goal.equals("/selftest");
        if (AgentService.inst == null) { startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)); return; }
        if (!test && !Store.hasKey(this)) { showSettings(); return; }
        input.setText("");
        InputMethodManager im = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
        im.hideSoftInputFromWindow(input.getWindowToken(), 0);
        if (test) Runner.selfTest(this); else Runner.start(this, goal);
    }

    private View bubble(Runner.Entry e) {
        LinearLayout wrap = new LinearLayout(this);
        wrap.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams wl = new LinearLayout.LayoutParams(-1, -2);
        wl.topMargin = dp(e.type == Runner.STEP || e.type == Runner.NOTE ? 4 : 12);
        wrap.setLayoutParams(wl);
        TextView t;
        if (e.type == Runner.USER) {
            wrap.setGravity(Gravity.END);
            t = text(e.text, 15, th.dark, false);
            t.setPadding(dp(16), dp(10), dp(16), dp(10));
            t.setBackground(round(th.text, 20, th.text));
            t.setMaxWidth(dp(280));
        } else if (e.type == Runner.AGENT) {
            t = text(e.text, 15, th.text, false);
            t.setPadding(dp(16), dp(10), dp(16), dp(10));
            t.setBackground(round(th.surface, 20, th.stroke));
            t.setMaxWidth(dp(300));
        } else {
            t = text((e.type == Runner.STEP ? "\u2022  " : "") + e.text, 12, th.muted, false);
            t.setPadding(dp(6), 0, dp(6), 0);
        }
        wrap.addView(t);
        return wrap;
    }

    private View chip(final String s) {
        TextView t = text(s, 14, th.text, false);
        t.setPadding(dp(16), dp(10), dp(16), dp(10));
        t.setBackground(round(th.surface, 18, th.stroke));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
        lp.topMargin = dp(6);
        t.setLayoutParams(lp);
        t.setOnClickListener(v -> { input.setText(s); input.setSelection(s.length()); });
        return t;
    }

    private View setupRow(String label, boolean done, String action, View.OnClickListener c) {
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(0, dp(10), 0, 0);
        row.addView(dot(done ? th.ok : th.warn), new LinearLayout.LayoutParams(dp(8), dp(8)));
        TextView t = text(label, 14, th.text, false);
        t.setPadding(dp(10), 0, 0, 0);
        row.addView(t, new LinearLayout.LayoutParams(0, -2, 1f));
        if (!done) {
            TextView b = pill(action, true);
            b.setOnClickListener(c);
            row.addView(b);
        } else {
            row.addView(text("Done", 12, th.muted, false));
        }
        return row;
    }

    // ---------------- settings ----------------

    private void showSettings() {
        inSettings = true;
        host.removeAllViews();
        host.setBackgroundColor(th.bg);
        final LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(44), dp(20), dp(20));

        TextView back = pill("Back", false);
        back.setOnClickListener(v -> showHome());
        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.addView(text("Settings", 28, th.text, true), new LinearLayout.LayoutParams(0, -2, 1f));
        top.addView(back);
        root.addView(top);

        // ---- look: theme picker + island toggle ----
        root.addView(label("Look"));
        LinearLayout themeRow = new LinearLayout(this);
        themeRow.setOrientation(LinearLayout.HORIZONTAL);
        for (final Theme opt : Theme.ALL) {
            themeRow.addView(themeCard(opt), new LinearLayout.LayoutParams(0, -2, 1f));
        }
        root.addView(themeRow);

        root.addView(label("Floating island"));
        TextView islandHelp = text("The small Pilot pill at the top of your screen. It stays on every screen - tap it to type or speak a task, and stop a running task.", 12, th.muted, false);
        islandHelp.setPadding(0, 0, 0, dp(8));
        root.addView(islandHelp);
        TextView islandToggle = pill(Store.islandOn(this) ? "On" : "Off", Store.islandOn(this));
        islandToggle.setPadding(dp(28), dp(12), dp(28), dp(12));
        islandToggle.setOnClickListener(v -> {
            boolean now = !Store.islandOn(this);
            Store.setIsland(this, now);
            AgentService s2 = AgentService.inst;
            if (s2 != null) {
                if (now) Island.show(s2); else Island.hide();
            }
            showSettings();
        });
        root.addView(islandToggle);

        // ---- AI provider ----
        root.addView(label("AI provider"));
        final LinearLayout seg = new LinearLayout(this);
        seg.setOrientation(LinearLayout.HORIZONTAL);
        root.addView(seg);

        final TextView keyHelp = text("", 12, th.muted, false);
        final EditText key = field("Paste your API key", true);
        final EditText model = field("Model name", false);
        final EditText base = field("API address", false);
        final TextView baseLabel = label("API address");
        final TextView status = text("", 13, th.muted, false);

        final Runnable render = new Runnable() {
            @Override public void run() {
                seg.removeAllViews();
                final boolean g = Store.GEMINI.equals(Store.provider(MainActivity.this));
                seg.addView(segBtn("Google Gemini (free)", g, v -> { Store.setProvider(MainActivity.this, Store.GEMINI); showSettings(); }));
                seg.addView(segBtn("Other (Groq etc.)", !g, v -> { Store.setProvider(MainActivity.this, Store.OTHER); showSettings(); }));
                keyHelp.setText(g ? "Get a free key at aistudio.google.com, then paste it here. The key stays on this phone, encrypted."
                        : "Any OpenAI-compatible service works. Groq has a free tier. The key stays on this phone, encrypted.");
                baseLabel.setVisibility(g ? View.GONE : View.VISIBLE);
                base.setVisibility(g ? View.GONE : View.VISIBLE);
                model.setText(Store.model(MainActivity.this));
                base.setText(Store.baseUrl(MainActivity.this));
                key.setText("");
                key.setHint(Store.hasKey(MainActivity.this) ? "Key saved. Paste a new one to replace" : "Paste your API key");
            }
        };

        root.addView(label("API key"));
        root.addView(key);
        root.addView(keyHelp);
        root.addView(label("Model"));
        root.addView(model);
        root.addView(baseLabel);
        root.addView(base);

        TextView save = pill("Save", true);
        save.setPadding(dp(28), dp(12), dp(28), dp(12));
        save.setOnClickListener(v -> {
            String k = key.getText().toString().trim();
            if (!k.isEmpty()) Store.setKey(this, k);
            if (!model.getText().toString().trim().isEmpty()) Store.setModel(this, model.getText().toString());
            if (base.getVisibility() == View.VISIBLE && !base.getText().toString().trim().isEmpty())
                Store.setBaseUrl(this, base.getText().toString());
            status.setText("Saved.");
            key.setText("");
            key.setHint("Key saved. Paste a new one to replace");
        });
        TextView clear = pill("Remove key", false);
        clear.setOnClickListener(v -> { Store.clearKey(this); status.setText("Key removed."); key.setHint("Paste your API key"); });
        LinearLayout actions = new LinearLayout(this);
        actions.setGravity(Gravity.CENTER_VERTICAL);
        actions.setPadding(0, dp(18), 0, 0);
        actions.addView(save);
        LinearLayout.LayoutParams cl = new LinearLayout.LayoutParams(-2, -2);
        cl.leftMargin = dp(10);
        actions.addView(clear, cl);
        root.addView(actions);
        status.setPadding(0, dp(10), 0, 0);
        root.addView(status);

        TextView note = text("Pilot sends the text on your screen to the AI service you chose, only while a task runs. "
                + "It will not touch banking or payment apps, never types passwords, and asks before anything risky.", 12, th.muted, false);
        note.setPadding(0, dp(24), 0, 0);
        root.addView(note);

        render.run();
        ScrollView sv = new ScrollView(this);
        sv.addView(root);
        host.addView(sv, new FrameLayout.LayoutParams(-1, -1));
    }

    private View themeCard(final Theme opt) {
        final boolean on = opt.id.equals(th.id);
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setGravity(Gravity.CENTER_HORIZONTAL);
        card.setPadding(dp(6), dp(10), dp(6), dp(10));
        card.setBackground(round(on ? opt.surface2 : th.surface, 18, on ? opt.text : th.stroke));

        // mini preview: bg tile with a surface pill and a blob dot
        LinearLayout prev = new LinearLayout(this);
        prev.setGravity(Gravity.CENTER);
        prev.setPadding(dp(6), dp(8), dp(6), dp(8));
        GradientDrawable pv = new GradientDrawable();
        pv.setColor(opt.bg);
        pv.setCornerRadius(dp(12));
        pv.setStroke(dp(1), opt.stroke);
        prev.setBackground(pv);
        MascotView m = new MascotView(this);
        if (Theme.PORCELAIN.equals(opt.id)) m.setColors(opt.text, opt.bg);
        prev.addView(m, new LinearLayout.LayoutParams(dp(26), dp(26)));
        card.addView(prev, new LinearLayout.LayoutParams(-1, dp(44)));

        TextView name = text(opt.name, 12, on ? th.text : th.muted, on);
        name.setGravity(Gravity.CENTER);
        name.setPadding(0, dp(8), 0, 0);
        card.addView(name);
        if (on) {
            TextView tick = text("\u2713", 12, th.ok, true);
            tick.setGravity(Gravity.CENTER);
            card.addView(tick);
        } else {
            TextView tick = text(" ", 12, th.muted, false);
            card.addView(tick);
        }

        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
        lp.setMargins(dp(4), dp(8), dp(4), 0);
        card.setLayoutParams(lp);
        card.setOnClickListener(v -> {
            Store.setTheme(this, opt.id);
            th = Theme.get(this);
            Island.applyTheme();
            showSettings();
        });
        return card;
    }

    private View segBtn(String s, boolean on, View.OnClickListener c) {
        TextView t = text(s, 13, on ? th.dark : th.text, true);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(14), dp(10), dp(14), dp(10));
        t.setBackground(round(on ? th.text : th.surface, 18, on ? th.text : th.stroke));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
        lp.rightMargin = dp(8);
        lp.topMargin = dp(8);
        t.setLayoutParams(lp);
        t.setOnClickListener(c);
        return t;
    }

    private TextView label(String s) {
        TextView t = text(s, 12, th.muted, false);
        t.setPadding(0, dp(20), 0, dp(6));
        return t;
    }

    private EditText field(String hint, boolean secret) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setHintTextColor(th.muted);
        e.setTextColor(th.text);
        e.setTextSize(15);
        e.setSingleLine(true);
        e.setInputType(secret ? (InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD)
                : (InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI));
        e.setPadding(dp(16), dp(12), dp(16), dp(12));
        e.setBackground(round(th.surface, 16, th.stroke));
        return e;
    }

    // ---------------- small helpers ----------------

    private TextView text(String s, int sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(null, Typeface.BOLD);
        return t;
    }

    private TextView pill(String s, boolean primary) {
        TextView t = text(s, 13, primary ? th.dark : th.text, true);
        t.setPadding(dp(14), dp(8), dp(14), dp(8));
        t.setBackground(round(primary ? th.text : th.surface2, 18, primary ? th.text : th.stroke));
        return t;
    }

    private View dot(int color) {
        View v = new View(this);
        v.setBackground(oval(color));
        return v;
    }

    private GradientDrawable round(int fill, int radiusDp, int stroke) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(fill);
        g.setCornerRadius(dp(radiusDp));
        g.setStroke(dp(1), stroke);
        return g;
    }

    private GradientDrawable oval(int fill) {
        GradientDrawable g = new GradientDrawable();
        g.setShape(GradientDrawable.OVAL);
        g.setColor(fill);
        return g;
    }

    private int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density + 0.5f); }
}
