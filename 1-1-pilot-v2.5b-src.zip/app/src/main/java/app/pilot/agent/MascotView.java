package app.pilot.agent;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.os.Handler;
import android.os.Looper;
import android.view.View;

/**
 * Pilot's little blob companion, drawn fully in code (no assets).
 * Flat design, off-white blob on charcoal. States: idle (breathes, blinks,
 * sleeps with rising z's), working (clear bobbing, wandering eyes), confirm
 * (pulsing amber ! badge), finished (pop + happy eyes + green check), error
 * (dizzy shake with X eyes). Original character, our own silhouette.
 */
public class MascotView extends View {
    public static final int IDLE = 0, WORKING = 1, CONFIRM = 2, FINISHED = 3, ERROR = 4;

    private static final int BODY = 0xFFF4F2EE;
    private static final int INK = 0xFF161617;
    private static final int AMBER = 0xFFE0A458;
    private static final int GREEN = 0xFF7BC47F;
    private static final int BLUSH = 0x2EC97B6B;

    private static final long SLEEP_AFTER_MS = 90000;

    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Handler h = new Handler(Looper.getMainLooper());
    private int bodyColor = BODY;
    private int inkColor = INK;
    private int state = IDLE;
    private long stateSetAt = System.currentTimeMillis();

    private final Runnable tick = new Runnable() {
        @Override public void run() {
            invalidate();
            h.postDelayed(this, 90);
        }
    };

    public MascotView(Context c) { super(c); }

    /** Theme colors: blob body and the ink used for eyes, mouth and badge glyphs. */
    public void setColors(int body, int ink) {
        bodyColor = body;
        inkColor = ink;
        invalidate();
    }

    public void setState(int s) {
        if (s != state) {
            state = s;
            stateSetAt = System.currentTimeMillis();
            invalidate();
        }
    }

    @Override protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        h.removeCallbacks(tick);
        h.post(tick);
    }

    @Override protected void onDetachedFromWindow() {
        h.removeCallbacks(tick);
        super.onDetachedFromWindow();
    }

    @Override protected void onDraw(Canvas c) {
        float w = getWidth(), hh = getHeight();
        float t = (System.currentTimeMillis() - stateSetAt) / 1000f;
        float wall = System.currentTimeMillis() / 1000f;
        boolean sleeping = state == IDLE && (System.currentTimeMillis() - stateSetAt) > SLEEP_AFTER_MS;

        // body: our blob - wider than tall, small bump on the top-left
        float bw = w * 0.86f, bh = hh * 0.72f;
        float cx = w / 2f, cy = hh / 2f + hh * 0.06f;
        // motion: breathing in idle, clear bob while working, pop on finish, shake on error
        float scaleX = 1f, scaleY = 1f, rot = 0f;
        if (state == WORKING) {
            cy += (float) Math.sin(wall * 6.0) * hh * 0.11f;
            float sq = 1f + 0.10f * (float) Math.sin(wall * 6.0 + 0.9f);
            scaleX = 2f - sq; scaleY = sq;
        } else if (state == FINISHED && t < 0.6f) {
            float k = 1f + 0.30f * (float) Math.sin(Math.min(1f, t / 0.6f) * Math.PI);
            scaleX = k; scaleY = k;
        } else if (state == ERROR) {
            cx += (float) Math.sin(wall * 14) * hh * 0.06f;
            rot = (float) Math.sin(wall * 14 + 0.7f) * 8f;
        } else if (!sleeping) {
            float br = 1f + 0.03f * (float) Math.sin(wall * 2.1);
            scaleX = br; scaleY = 2f - br;
        }
        c.save();
        c.translate(cx, cy);
        c.rotate(rot);
        c.scale(scaleX, scaleY);
        RectF body = new RectF(-bw / 2, -bh / 2, bw / 2, bh / 2);
        p.setStyle(Paint.Style.FILL);
        p.setColor(bodyColor);
        Path blob = new Path();
        blob.addRoundRect(body, bh * 0.52f, bh * 0.52f, Path.Direction.CW);
        c.drawPath(blob, p);
        c.drawCircle(body.left + bw * 0.20f, body.top + bh * 0.04f, bh * 0.15f, p);

        // eyes
        float eyeY = -bh * 0.08f;
        float eyeDx = bw * 0.17f;
        float wander = state == WORKING ? (float) Math.sin(wall * 2.4) * bw * 0.05f : 0;
        boolean blink = (state == IDLE || state == WORKING) && !sleeping && (wall % 3.7f) < 0.13f;
        p.setColor(inkColor);
        if (state == FINISHED) {
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(hh * 0.05f);
            p.setStrokeCap(Paint.Cap.ROUND);
            for (int sgn = -1; sgn <= 1; sgn += 2) {
                float ex = sgn * eyeDx;
                c.drawArc(new RectF(ex - hh * 0.06f, eyeY - hh * 0.05f, ex + hh * 0.06f, eyeY + hh * 0.06f), 200, 140, false, p);
            }
            p.setStyle(Paint.Style.FILL);
        } else if (state == ERROR) {
            // dizzy X eyes
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(hh * 0.045f);
            p.setStrokeCap(Paint.Cap.ROUND);
            float ex2 = hh * 0.05f;
            for (int sgn = -1; sgn <= 1; sgn += 2) {
                float ex = sgn * eyeDx;
                c.drawLine(ex - ex2, eyeY - ex2, ex + ex2, eyeY + ex2, p);
                c.drawLine(ex - ex2, eyeY + ex2, ex + ex2, eyeY - ex2, p);
            }
            p.setStyle(Paint.Style.FILL);
        } else if (sleeping) {
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(hh * 0.04f);
            p.setStrokeCap(Paint.Cap.ROUND);
            c.drawLine(-eyeDx - hh * 0.05f, eyeY, -eyeDx + hh * 0.05f, eyeY, p);
            c.drawLine(eyeDx - hh * 0.05f, eyeY, eyeDx + hh * 0.05f, eyeY, p);
            p.setStyle(Paint.Style.FILL);
            // rising z's
            p.setTextAlign(Paint.Align.CENTER);
            p.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
            for (int i = 0; i < 2; i++) {
                float ph = ((wall * 0.45f + i * 0.5f) % 1f);
                float zx = bw * 0.34f + ph * bw * 0.18f;
                float zy = -bh * 0.30f - ph * bh * 0.55f;
                p.setColor(inkColor);
                p.setAlpha((int) (255 * (1f - ph)));
                p.setTextSize(hh * (0.16f + ph * 0.14f));
                c.drawText("z", zx, zy, p);
                p.setAlpha(255);
            }
            p.setTypeface(android.graphics.Typeface.DEFAULT);
        } else {
            float eh = blink ? hh * 0.02f : hh * 0.11f;
            float ew = hh * 0.055f;
            c.drawOval(new RectF(-eyeDx - ew / 2 + wander, eyeY - eh / 2, -eyeDx + ew / 2 + wander, eyeY + eh / 2), p);
            c.drawOval(new RectF(eyeDx - ew / 2 + wander, eyeY - eh / 2, eyeDx + ew / 2 + wander, eyeY + eh / 2), p);
        }

        // blush dashes
        p.setColor(BLUSH);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(hh * 0.028f);
        c.drawLine(-bw * 0.30f, bh * 0.10f, -bw * 0.22f, bh * 0.10f, p);
        c.drawLine(bw * 0.22f, bh * 0.10f, bw * 0.30f, bh * 0.10f, p);
        p.setStyle(Paint.Style.FILL);

        // mouth
        p.setColor(inkColor);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(hh * 0.035f);
        p.setStrokeCap(Paint.Cap.ROUND);
        float my = bh * 0.17f;
        if (state == FINISHED) {
            c.drawArc(new RectF(-hh * 0.07f, my - hh * 0.05f, hh * 0.07f, my + hh * 0.07f), 20, 140, false, p);
        } else if (state == ERROR) {
            c.drawArc(new RectF(-hh * 0.06f, my, hh * 0.06f, my + hh * 0.10f), 200, 140, false, p);
        } else if (state == WORKING || sleeping) {
            c.drawCircle(0, my, hh * 0.028f, p);
        } else {
            c.drawLine(-hh * 0.05f, my, hh * 0.05f, my, p);
        }
        p.setStyle(Paint.Style.FILL);

        // badge (confirm / finished) - confirm badge pulses
        if (state == CONFIRM || state == FINISHED) {
            p.setColor(state == CONFIRM ? AMBER : GREEN);
            float br = hh * (state == CONFIRM ? 0.17f + 0.025f * (float) Math.sin(wall * 7) : 0.16f);
            float bx = bw / 2 - br * 0.3f, by = -bh / 2 + br * 0.3f;
            c.drawCircle(bx, by, br, p);
            p.setColor(inkColor);
            p.setTextSize(br * 1.5f);
            p.setTextAlign(Paint.Align.CENTER);
            p.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
            Paint.FontMetrics fm = p.getFontMetrics();
            c.drawText(state == CONFIRM ? "!" : "\u2713", bx, by - (fm.ascent + fm.descent) / 2f, p);
            p.setTypeface(android.graphics.Typeface.DEFAULT);
        }
        c.restore();
    }
}
