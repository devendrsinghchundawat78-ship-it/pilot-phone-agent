package app.pilot.agent;

import android.app.Activity;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/** Saved past tasks: goal, outcome and full transcript. On-device only. */
public class HistoryActivity extends Activity {
    private Theme th;
    private FrameLayout host;
    private List<History.Item> items;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        th = Theme.get(this);
        host = new FrameLayout(this);
        host.setBackgroundColor(th.bg);
        getWindow().getDecorView().setBackgroundColor(th.bg);
        setContentView(host);
        showList();
    }

    // ---------------- list ----------------

    private void showList() {
        host.removeAllViews();
        items = History.list(this);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(44), dp(20), dp(16));

        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout titles = new LinearLayout(this);
        titles.setOrientation(LinearLayout.VERTICAL);
        titles.addView(text("History", 28, th.text, true));
        titles.addView(text(items.isEmpty() ? "Your past tasks live here" : items.size() + " saved task" + (items.size() == 1 ? "" : "s"), 13, th.muted, false));
        top.addView(titles, new LinearLayout.LayoutParams(0, -2, 1f));
        if (!items.isEmpty()) {
            TextView clear = pill("Clear", false);
            clear.setOnClickListener(v -> { History.clear(this); showList(); });
            top.addView(clear);
            TextView sp = new TextView(this);
            top.addView(sp, new LinearLayout.LayoutParams(dp(8), 1));
        }
        TextView back = pill("Back", false);
        back.setOnClickListener(v -> finish());
        top.addView(back);
        root.addView(top);

        ScrollView sv = new ScrollView(this);
        sv.setVerticalScrollBarEnabled(false);
        LinearLayout list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        sv.addView(list, new ViewGroup.LayoutParams(-1, -2));

        if (items.isEmpty()) {
            LinearLayout empty = new LinearLayout(this);
            empty.setOrientation(LinearLayout.VERTICAL);
            empty.setGravity(Gravity.CENTER_HORIZONTAL);
            empty.setPadding(0, dp(80), 0, 0);
            MascotView m = new MascotView(this);
            if (Theme.PORCELAIN.equals(th.id)) m.setColors(th.text, th.bg);
            empty.addView(m, new LinearLayout.LayoutParams(dp(64), dp(64)));
            TextView t = text("No tasks yet", 15, th.muted, false);
            t.setPadding(0, dp(14), 0, 0);
            empty.addView(t);
            TextView h = text("Every task you give Pilot is saved here with its transcript.", 12, th.muted, false);
            h.setGravity(Gravity.CENTER);
            h.setPadding(dp(30), dp(6), dp(30), 0);
            empty.addView(h);
            list.addView(empty, new LinearLayout.LayoutParams(-1, -2));
        } else {
            for (int i = 0; i < items.size(); i++) {
                final History.Item it = items.get(i);
                LinearLayout card = new LinearLayout(this);
                card.setOrientation(LinearLayout.VERTICAL);
                card.setPadding(dp(16), dp(12), dp(16), dp(12));
                card.setBackground(round(th.surface, 18, th.stroke));

                LinearLayout first = new LinearLayout(this);
                first.setGravity(Gravity.CENTER_VERTICAL);
                first.addView(dot("Done".equals(it.status) ? th.ok : th.warn), new LinearLayout.LayoutParams(dp(8), dp(8)));
                TextView g = text(it.goal.isEmpty() ? "(task)" : it.goal, 15, th.text, true);
                g.setMaxLines(2);
                g.setEllipsize(android.text.TextUtils.TruncateAt.END);
                g.setPadding(dp(10), 0, 0, 0);
                first.addView(g, new LinearLayout.LayoutParams(0, -2, 1f));
                card.addView(first);

                TextView meta = text(when(it.ts) + "  ·  " + it.status + "  ·  " + it.steps + " step" + (it.steps == 1 ? "" : "s"), 12, th.muted, false);
                meta.setPadding(dp(18), dp(6), 0, 0);
                card.addView(meta);

                LinearLayout.LayoutParams cl = new LinearLayout.LayoutParams(-1, -2);
                cl.topMargin = dp(10);
                list.addView(card, cl);
                final int idx = i;
                card.setOnClickListener(v -> showDetail(idx));
            }
        }

        LinearLayout.LayoutParams svl = new LinearLayout.LayoutParams(-1, 0, 1f);
        svl.topMargin = dp(16);
        root.addView(sv, svl);
        host.addView(root, new FrameLayout.LayoutParams(-1, -1));
    }

    // ---------------- detail ----------------

    private void showDetail(int idx) {
        if (idx < 0 || idx >= items.size()) return;
        final History.Item it = items.get(idx);
        host.removeAllViews();

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(44), dp(20), dp(16));

        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        TextView back = pill("Back", false);
        back.setOnClickListener(v -> showList());
        top.addView(back, new LinearLayout.LayoutParams(-2, -2));
        TextView status = text("  " + it.status, 13, "Done".equals(it.status) ? th.ok : th.warn, true);
        top.addView(status, new LinearLayout.LayoutParams(0, -2, 1f));
        root.addView(top);

        TextView goal = text(it.goal, 20, th.text, true);
        goal.setPadding(0, dp(14), 0, 0);
        root.addView(goal);
        TextView meta = text(when(it.ts) + "  ·  " + it.steps + " steps", 12, th.muted, false);
        meta.setPadding(0, dp(4), 0, dp(10));
        root.addView(meta);

        ScrollView sv = new ScrollView(this);
        sv.setVerticalScrollBarEnabled(false);
        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        sv.addView(body, new ViewGroup.LayoutParams(-1, -2));

        if (!it.message.isEmpty()) {
            TextView m = text(it.message, 14, th.text, false);
            m.setPadding(dp(14), dp(10), dp(14), dp(10));
            m.setBackground(round(th.surface, 16, th.stroke));
            body.addView(m, new LinearLayout.LayoutParams(-1, -2));
        }
        TextView th2 = text("Transcript", 12, th.muted, false);
        th2.setPadding(dp(4), dp(14), 0, dp(6));
        body.addView(th2);
        if (it.transcript.isEmpty()) {
            body.addView(text("(no transcript saved)", 12, th.muted, false));
        } else {
            for (String line : it.transcript) {
                boolean user = line.startsWith("You: ");
                boolean agent = line.startsWith("Pilot: ");
                TextView t = text(line, 12, user ? th.text : agent ? th.text : th.muted, user || agent);
                t.setPadding(dp(4), dp(3), dp(4), dp(3));
                body.addView(t);
            }
        }
        root.addView(sv, new LinearLayout.LayoutParams(-1, 0, 1f));

        TextView again = pill("Run again", true);
        again.setGravity(Gravity.CENTER);
        again.setPadding(dp(16), dp(12), dp(16), dp(12));
        LinearLayout.LayoutParams al = new LinearLayout.LayoutParams(-1, -2);
        al.topMargin = dp(10);
        root.addView(again, al);
        again.setOnClickListener(v -> {
            if (AgentService.inst == null || !Store.hasKey(this) || Runner.running) { finish(); return; }
            Runner.start(this, it.goal);
            finish();
        });

        host.addView(root, new FrameLayout.LayoutParams(-1, -1));
    }

    // ---------------- helpers ----------------

    private String when(long ts) {
        Calendar c = Calendar.getInstance();
        int todayYear = c.get(Calendar.YEAR), todayDay = c.get(Calendar.DAY_OF_YEAR);
        c.setTimeInMillis(ts);
        String day;
        if (c.get(Calendar.YEAR) == todayYear && c.get(Calendar.DAY_OF_YEAR) == todayDay) day = "Today";
        else {
            c.add(Calendar.DAY_OF_YEAR, 1);
            if (c.get(Calendar.YEAR) == todayYear && c.get(Calendar.DAY_OF_YEAR) == todayDay) day = "Yesterday";
            else day = new SimpleDateFormat("d MMM", Locale.getDefault()).format(new Date(ts));
        }
        return day + ", " + new SimpleDateFormat("h:mm a", Locale.getDefault()).format(new Date(ts));
    }

    private TextView text(String s, int sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(null, Typeface.BOLD);
        return t;
    }

    private TextView pill(String s, boolean primary) {
        TextView t = text(s, 13, primary ? th.dark : th.text, true);
        t.setPadding(dp(14), dp(8), dp(14), dp(8));
        t.setBackground(round(primary ? th.text : th.surface2, 18, primary ? th.text : th.stroke));
        return t;
    }

    private View dot(int color) {
        View v = new View(this);
        GradientDrawable g = new GradientDrawable();
        g.setShape(GradientDrawable.OVAL);
        g.setColor(color);
        v.setBackground(g);
        return v;
    }

    private GradientDrawable round(int fill, int radiusDp, int stroke) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(fill);
        g.setCornerRadius(dp(radiusDp));
        g.setStroke(dp(1), stroke);
        return g;
    }

    private int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density + 0.5f); }
}
