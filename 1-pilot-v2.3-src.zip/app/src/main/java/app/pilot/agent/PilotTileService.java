package app.pilot.agent;

import android.app.PendingIntent;
import android.content.Intent;
import android.service.quicksettings.Tile;
import android.service.quicksettings.TileService;

/** Quick Settings tile: opens the Pilot command panel from anywhere. */
public class PilotTileService extends TileService {
    @Override public void onStartListening() {
        Tile t = getQsTile();
        if (t == null) return;
        if (AgentService.inst == null) {
            t.setState(Tile.STATE_UNAVAILABLE);
            t.setSubtitle("Turn on accessibility first");
        } else {
            boolean on = Island.visible();
            t.setState(on ? Tile.STATE_ACTIVE : Tile.STATE_INACTIVE);
            t.setSubtitle(on ? "Island on" : "Island off");
        }
        t.updateTile();
    }

    @Override public void onClick() {
        AgentService s = AgentService.inst;
        if (s == null) {
            try {
                Intent i = new Intent(this, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivityAndCollapse(PendingIntent.getActivity(this, 0, i,
                        PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE));
            } catch (Throwable ignored) { }
            return;
        }
        try {
            Intent cmd = new Intent(this, CommandActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivityAndCollapse(PendingIntent.getActivity(this, 0, cmd,
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE));
        } catch (Throwable ignored) { }
        s.showOverlay(null);
        onStartListening();
    }
}
