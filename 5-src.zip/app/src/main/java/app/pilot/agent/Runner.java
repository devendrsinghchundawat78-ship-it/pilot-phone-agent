package app.pilot.agent;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.regex.Pattern;

/** The think-act loop: read screen, ask AI for one action, do it, repeat. */
final class Runner {
    static final int USER = 0, AGENT = 1, STEP = 2, NOTE = 3;

    static class Entry {
        final int type;
        final String text;
        Entry(int type, String text) { this.type = type; this.text = text; }
    }

    interface Listener { void onChange(); }

    static final List<Entry> log = new ArrayList<>();
    private static final java.util.concurrent.CopyOnWriteArrayList<Listener> listeners =
            new java.util.concurrent.CopyOnWriteArrayList<>();
    static volatile boolean running = false;
    private static volatile boolean stopFlag = false;
    private static final Handler MAIN = new Handler(Looper.getMainLooper());
    private static final int MAX_STEPS = 30;

    // Apps we never operate: banking and payment apps.
    private static final Pattern BLOCKED_PKG = Pattern.compile(
            "bank|paisa|phonepe|paytm|npci|upi|razorpay|bhim|mobikwik|freecharge|payu|cred\\.club|paypal|venmo|cashapp|revolut|wallet",
            Pattern.CASE_INSENSITIVE);
    // Taps on things that look like these need a yes from the user first.
    private static final Pattern RISKY = Pattern.compile(
            "\\b(pay|pay now|buy|buy now|purchase|place order|order now|send money|transfer|donate|delete|remove|erase|uninstall|factory reset|sign out|log out|logout|submit|confirm|post|publish|send)\\b",
            Pattern.CASE_INSENSITIVE);

    private static final String SYSTEM =
            "You are Pilot, an assistant that operates an Android phone for the user by reading the screen and doing ONE action at a time.\n"
          + "Each turn you get: the user's goal, what you already did, and the current screen as a numbered list of elements.\n"
          + "Reply with ONE JSON object only, no other text:\n"
          + "{\"thought\":\"very short reason\",\"action\":\"<name>\",\"index\":<number>,\"text\":\"...\",\"direction\":\"up|down\",\"app\":\"...\",\"seconds\":<number>,\"message\":\"...\"}\n"
          + "Actions:\n"
          + "- open_app: open an app by its name (field app). Use this to start; do not hunt for icons.\n"
          + "- tap: tap element number index.\n"
          + "- type: type text (field text) into element number index (or the focused field if index is missing). Add \"submit\":true to press search/enter after.\n"
          + "- scroll: scroll the screen (direction down moves to later content).\n"
          + "- back, home: system buttons.\n"
          + "- wait: wait seconds (1-5) for something to load.\n"
          + "- ask: you need info from the user or cannot continue. Put your question in message. Task pauses.\n"
          + "- done: the task is finished. Put a short result for the user in message (answer what was asked, e.g. read out the info).\n"
          + "Rules:\n"
          + "- Use only element numbers from the current screen. Numbers change every turn.\n"
          + "- Prefer the shortest path. If the screen did not change after your action, try something different.\n"
          + "- Never enter passwords, OTPs, card numbers or PINs. Use ask so the user does it.\n"
          + "- Before anything that spends money, sends a message or post to someone, or deletes data, use ask first unless the user's goal clearly said to do exactly that.\n"
          + "- Never operate banking or payment apps.\n"
          + "- Write messages in the same language the user used.";

    static void addListener(Listener l) { if (l != null) listeners.addIfAbsent(l); }

    static void removeListener(Listener l) { if (l != null) listeners.remove(l); }

    private static void notifyChange() {
        for (Listener l : listeners) MAIN.post(l::onChange);
    }

    static void say(int type, String text) {
        synchronized (log) { log.add(new Entry(type, text)); }
        notifyChange();
    }

    static void clear() {
        synchronized (log) { log.clear(); }
        notifyChange();
    }

    static void stop() {
        stopFlag = true;
    }

    static synchronized void start(final Context ctx, final String goal) {
        if (running) return;
        final Context app = ctx.getApplicationContext();
        running = true;
        stopFlag = false;
        say(USER, goal);
        final String context = recentContext();
        new Thread(() -> {
            try {
                loop(app, goal, context);
            } catch (Throwable t) {
                say(NOTE, "Stopped: " + (t.getMessage() == null ? t.toString() : t.getMessage()));
            } finally {
                running = false;
                AgentService s = AgentService.inst;
                if (s != null) s.hideOverlay();
                notifyChange();
            }
        }, "pilot-loop").start();
    }

    private static String recentContext() {
        StringBuilder sb = new StringBuilder();
        synchronized (log) {
            int from = Math.max(0, log.size() - 9); // last few lines before this goal
            for (int i = from; i < log.size() - 1; i++) {
                Entry e = log.get(i);
                if (e.type == USER) sb.append("User earlier said: ").append(e.text).append('\n');
                else if (e.type == AGENT) sb.append("You earlier replied: ").append(e.text).append('\n');
            }
        }
        return sb.toString();
    }

    private static void loop(Context app, String goal, String earlier) throws Exception {
        AgentService svc = AgentService.inst;
        if (svc == null) {
            say(NOTE, "Accessibility access is off. Turn it on first.");
            return;
        }
        if (!Store.hasKey(app)) {
            say(NOTE, "Add your AI key in Settings first.");
            return;
        }
        svc.showOverlay("Starting");
        svc.global(android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_HOME);
        sleep(900);

        List<String> done = new ArrayList<>();
        String lastSig = "";
        int repeats = 0;
        for (int step = 1; step <= MAX_STEPS; step++) {
            if (stopFlag) { say(NOTE, "Stopped."); return; }
            svc = AgentService.inst;
            if (svc == null) { say(NOTE, "Accessibility access was turned off."); return; }

            AgentService.Snap snap = svc.snapshot();
            if (snap.pkg != null && BLOCKED_PKG.matcher(snap.pkg).find()) {
                say(AGENT, "This looks like a banking or payment app. I do not operate those. Please do this part yourself.");
                return;
            }
            svc.showOverlay("Step " + step + " - thinking");

            StringBuilder u = new StringBuilder();
            if (!earlier.isEmpty()) u.append(earlier);
            u.append("GOAL: ").append(goal).append("\n");
            u.append("DONE SO FAR:\n");
            if (done.isEmpty()) u.append("(nothing yet)\n");
            int from = Math.max(0, done.size() - 12);
            for (int i = from; i < done.size(); i++) u.append(i + 1).append(". ").append(done.get(i)).append('\n');
            u.append("CURRENT SCREEN (app: ").append(snap.pkg).append("):\n").append(snap.text);

            String raw = Llm.ask(app, SYSTEM, u.toString());
            if (stopFlag) { say(NOTE, "Stopped."); return; }
            JSONObject a = parse(raw);
            if (a == null) {
                done.add("(my last reply was not valid, retry)");
                continue;
            }
            String action = a.optString("action", "").toLowerCase(Locale.ROOT);
            String thought = a.optString("thought", "");
            int index = a.optInt("index", -1);
            String text = a.optString("text", "");
            String message = a.optString("message", "");
            String result;

            String sig = action + "|" + index + "|" + text + "|" + a.optString("app", "") + "|" + snap.text.hashCode();
            repeats = sig.equals(lastSig) ? repeats + 1 : 0;
            lastSig = sig;
            if (repeats >= 2) {
                say(AGENT, "I am going in circles and cannot get further. Tell me what to try next.");
                return;
            }

            switch (action) {
                case "done":
                    say(AGENT, message.isEmpty() ? "Done." : message);
                    return;
                case "ask":
                    say(AGENT, message.isEmpty() ? "I need your help to continue." : message);
                    return;
                case "open_app": {
                    String name = a.optString("app", text);
                    say(STEP, "Open " + name);
                    result = svc.openApp(name);
                    break;
                }
                case "tap": {
                    String label = svc.labelOf(index);
                    say(STEP, "Tap " + (label.isEmpty() ? "#" + index : label));
                    if (RISKY.matcher(label).find() && !svc.confirm("Tap \"" + label + "\"?")) {
                        say(AGENT, "You did not allow that tap, so I stopped.");
                        return;
                    }
                    result = svc.tap(index);
                    break;
                }
                case "type": {
                    say(STEP, "Type \"" + shorten(text) + "\"");
                    result = svc.type(index, text, a.optBoolean("submit", false));
                    break;
                }
                case "scroll": {
                    String dir = a.optString("direction", "down");
                    say(STEP, "Scroll " + dir);
                    result = svc.scroll(dir);
                    break;
                }
                case "back":
                    say(STEP, "Back");
                    result = svc.global(android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_BACK) ? "ok" : "failed";
                    break;
                case "home":
                    say(STEP, "Home");
                    result = svc.global(android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_HOME) ? "ok" : "failed";
                    break;
                case "wait": {
                    int s = Math.max(1, Math.min(5, a.optInt("seconds", 2)));
                    say(STEP, "Wait " + s + "s");
                    sleep(s * 1000L);
                    result = "waited";
                    break;
                }
                default:
                    result = "unknown action";
            }
            done.add(action + (index >= 0 ? " #" + index : "") + (text.isEmpty() ? "" : " \"" + shorten(text) + "\"")
                    + (a.optString("app", "").isEmpty() ? "" : " " + a.optString("app")) + " -> " + result
                    + (thought.isEmpty() ? "" : " (" + shorten(thought) + ")"));
            sleep(1000);
        }
        say(AGENT, "I used all " + MAX_STEPS + " steps without finishing. Tell me if I should continue.");
    }

    static JSONObject parse(String raw) {
        if (raw == null) return null;
        String s = raw.trim();
        int i = s.indexOf('{');
        int j = s.lastIndexOf('}');
        if (i < 0 || j <= i) return null;
        try {
            return new JSONObject(s.substring(i, j + 1));
        } catch (Exception e) {
            return null;
        }
    }

    static String shorten(String s) {
        s = s.replace('\n', ' ');
        return s.length() > 60 ? s.substring(0, 57) + "..." : s;
    }

    static void sleep(long ms) {
        try { Thread.sleep(ms); } catch (InterruptedException ignored) { Thread.currentThread().interrupt(); }
    }

    /** No-AI check used to prove the service can really drive other apps. */
    static synchronized void selfTest(Context ctx) {
        if (running) return;
        running = true;
        stopFlag = false;
        say(USER, "/selftest");
        new Thread(() -> {
            try {
                AgentService s = AgentService.inst;
                if (s == null) { say(NOTE, "Accessibility access is off."); return; }
                s.showOverlay("Self test");
                say(STEP, "Home");
                s.global(android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_HOME);
                sleep(1200);
                say(STEP, "Open Settings");
                say(NOTE, s.openApp("Settings"));
                sleep(2500);
                AgentService.Snap sn = s.snapshot();
                say(STEP, "Read screen of " + sn.pkg);
                int lines = sn.text.split("\n").length;
                say(NOTE, "Saw " + lines + " elements on screen.");
                say(STEP, "Scroll down");
                say(NOTE, s.scroll("down"));
                sleep(1200);
                say(AGENT, "Self test finished. I opened Settings, read the screen and scrolled by myself.");
            } catch (Throwable t) {
                say(NOTE, "Self test failed: " + t);
            } finally {
                running = false;
                AgentService s = AgentService.inst;
                if (s != null) s.hideOverlay();
                notifyChange();
            }
        }, "pilot-selftest").start();
    }
}
