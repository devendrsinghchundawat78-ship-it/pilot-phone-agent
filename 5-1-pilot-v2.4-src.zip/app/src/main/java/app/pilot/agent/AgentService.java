package app.pilot.agent;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Path;
import android.graphics.Rect;
import android.os.Build;
import android.os.Bundle;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

/** The hands and eyes: reads the screen and performs taps, typing and scrolls. */
public class AgentService extends AccessibilityService {
    static volatile AgentService inst;

    static class Snap {
        String pkg;
        String text;
    }

    private final List<AccessibilityNodeInfo> nodes = new ArrayList<>();

    @Override protected void onServiceConnected() {
        inst = this;
        if (Store.islandOn(this)) Island.show(this);
    }

    @Override public void onAccessibilityEvent(AccessibilityEvent event) { }
    @Override public void onInterrupt() { }

    @Override public void onDestroy() {
        Runner.stop();
        Island.hide();
        inst = null;
        super.onDestroy();
    }

    @Override public boolean onUnbind(Intent intent) {
        Runner.stop();
        Island.hide();
        inst = null;
        return super.onUnbind(intent);
    }

    // ---------- reading the screen ----------

    synchronized Snap snapshot() {
        nodes.clear();
        Snap s = new Snap();
        AccessibilityNodeInfo root = null;
        for (int i = 0; i < 5 && root == null; i++) {
            root = getRootInActiveWindow();
            if (root == null) Runner.sleep(400);
        }
        if (root == null) {
            s.pkg = "unknown";
            s.text = "(screen not readable right now)";
            return s;
        }
        s.pkg = String.valueOf(root.getPackageName());
        StringBuilder sb = new StringBuilder();
        walk(root, sb, 0);
        s.text = nodes.isEmpty() ? "(no readable elements)" : sb.toString();
        return s;
    }

    private void walk(AccessibilityNodeInfo n, StringBuilder sb, int depth) {
        if (n == null || nodes.size() >= 150 || depth > 40) return;
        if (!n.isVisibleToUser()) return;
        CharSequence t = n.getText();
        CharSequence d = n.getContentDescription();
        boolean has = (t != null && t.length() > 0) || (d != null && d.length() > 0);
        boolean useful = has || n.isClickable() || n.isEditable() || n.isScrollable() || n.isCheckable();
        if (useful) {
            int idx = nodes.size();
            nodes.add(n);
            String cls = String.valueOf(n.getClassName());
            cls = cls.substring(cls.lastIndexOf('.') + 1);
            sb.append('[').append(idx).append("] ").append(cls);
            if (n.isPassword()) {
                sb.append(" PASSWORD_FIELD (hidden)");
            } else {
                if (t != null && t.length() > 0) sb.append(" \"").append(clip(t.toString())).append('"');
                if (d != null && d.length() > 0 && (t == null || !d.toString().contentEquals(t)))
                    sb.append(" (").append(clip(d.toString())).append(')');
            }
            if (n.isClickable()) sb.append(" tap");
            if (n.isEditable()) sb.append(" edit");
            if (n.isScrollable()) sb.append(" scroll");
            if (n.isCheckable()) sb.append(n.isChecked() ? " checked" : " unchecked");
            if (n.isFocused()) sb.append(" focused");
            sb.append('\n');
        }
        for (int i = 0; i < n.getChildCount(); i++) walk(n.getChild(i), sb, depth + 1);
    }

    private static String clip(String s) {
        s = s.replace('\n', ' ');
        return s.length() > 80 ? s.substring(0, 77) + "..." : s;
    }

    String labelOf(int idx) {
        if (idx < 0 || idx >= nodes.size()) return "";
        AccessibilityNodeInfo n = nodes.get(idx);
        if (n.getText() != null && n.getText().length() > 0) return clip(n.getText().toString());
        if (n.getContentDescription() != null) return clip(n.getContentDescription().toString());
        return "";
    }

    // ---------- actions ----------

    String tap(int idx) {
        if (idx < 0 || idx >= nodes.size()) return "no such element";
        AccessibilityNodeInfo n = nodes.get(idx);
        AccessibilityNodeInfo c = n;
        while (c != null && !c.isClickable()) c = c.getParent();
        if (c != null && c.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return "tapped";
        Rect r = new Rect();
        n.getBoundsInScreen(r);
        return gesture(r.centerX(), r.centerY(), r.centerX(), r.centerY(), 60) ? "tapped" : "tap failed";
    }

    String type(int idx, String text, boolean submit) {
        AccessibilityNodeInfo n = null;
        if (idx >= 0 && idx < nodes.size()) n = nodes.get(idx);
        if (n == null) {
            for (AccessibilityNodeInfo x : nodes) if (x.isEditable() && x.isFocused()) { n = x; break; }
        }
        if (n == null) {
            for (AccessibilityNodeInfo x : nodes) if (x.isEditable()) { n = x; break; }
        }
        if (n == null) return "no text field found";
        if (n.isPassword()) return "refused: password field, ask the user to type it";
        n.performAction(AccessibilityNodeInfo.ACTION_FOCUS);
        n.performAction(AccessibilityNodeInfo.ACTION_CLICK);
        Bundle b = new Bundle();
        b.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text);
        boolean ok = n.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, b);
        if (!ok) return "typing failed";
        if (submit) {
            Runner.sleep(500);
            if (Build.VERSION.SDK_INT >= 30) {
                n.performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_IME_ENTER.getId());
            }
        }
        return "typed";
    }

    String scroll(String dir) {
        boolean down = !"up".equalsIgnoreCase(dir);
        AccessibilityNodeInfo sc = null;
        for (AccessibilityNodeInfo x : nodes) if (x.isScrollable()) { sc = x; break; }
        if (sc != null) {
            int act = down ? AccessibilityNodeInfo.AccessibilityAction.ACTION_SCROLL_FORWARD.getId()
                    : AccessibilityNodeInfo.AccessibilityAction.ACTION_SCROLL_BACKWARD.getId();
            if (sc.performAction(act)) return "scrolled";
        }
        android.util.DisplayMetrics m = getResources().getDisplayMetrics();
        int x = m.widthPixels / 2;
        int y1 = (int) (m.heightPixels * (down ? 0.75 : 0.30));
        int y2 = (int) (m.heightPixels * (down ? 0.30 : 0.75));
        return gesture(x, y1, x, y2, 350) ? "scrolled" : "scroll failed";
    }

    boolean global(int action) { return performGlobalAction(action); }

    private boolean gesture(int x1, int y1, int x2, int y2, long ms) {
        Path p = new Path();
        p.moveTo(x1, y1);
        if (x1 != x2 || y1 != y2) p.lineTo(x2, y2);
        GestureDescription g = new GestureDescription.Builder()
                .addStroke(new GestureDescription.StrokeDescription(p, 0, ms)).build();
        final CountDownLatch l = new CountDownLatch(1);
        final boolean[] ok = {false};
        boolean sent = dispatchGesture(g, new GestureResultCallback() {
            @Override public void onCompleted(GestureDescription d) { ok[0] = true; l.countDown(); }
            @Override public void onCancelled(GestureDescription d) { l.countDown(); }
        }, null);
        if (!sent) return false;
        try { l.await(3, TimeUnit.SECONDS); } catch (InterruptedException ignored) { }
        return ok[0];
    }

    String openApp(String name) {
        if (name == null || name.trim().isEmpty()) return "no app name";
        PackageManager pm = getPackageManager();
        Intent q = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER);
        List<ResolveInfo> apps = pm.queryIntentActivities(q, 0);
        String want = name.trim().toLowerCase(Locale.ROOT);
        ResolveInfo best = null;
        int bestScore = 0;
        for (ResolveInfo ri : apps) {
            String label = String.valueOf(ri.loadLabel(pm)).toLowerCase(Locale.ROOT);
            int score = 0;
            if (label.equals(want)) score = 3;
            else if (label.startsWith(want)) score = 2;
            else if (label.contains(want) || want.contains(label)) score = 1;
            if (score > bestScore) { bestScore = score; best = ri; }
        }
        if (best == null) return "app not found";
        String pkg = best.activityInfo.packageName;
        if (java.util.regex.Pattern.compile("bank|paisa|phonepe|paytm|npci|upi|razorpay|bhim|paypal|wallet").matcher(pkg).find())
            return "refused: payment or banking app";
        Intent i = pm.getLaunchIntentForPackage(pkg);
        if (i == null) return "cannot launch";
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED);
        startActivity(i);
        Runner.sleep(1800);
        return "opened " + best.loadLabel(pm);
    }

    /** Open a web address in the user's browser. */
    String openUrl(String url) {
        if (url == null || url.trim().isEmpty()) return "no url";
        String u = url.trim();
        if (!u.contains("://")) u = "https://" + u;
        try {
            Intent i = new Intent(Intent.ACTION_VIEW, android.net.Uri.parse(u));
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
            Runner.sleep(1800);
            return "opened " + u;
        } catch (Throwable t) {
            return "cannot open that address";
        }
    }

    /** Open the browser's downloads list so a downloaded file can be verified. */
    String openDownloads() {
        try {
            Intent i = new Intent("android.intent.action.VIEW_DOWNLOADS");
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
            Runner.sleep(1800);
            return "opened downloads";
        } catch (Throwable t) {
            return "cannot open the downloads list";
        }
    }

    // ---------- permanent top island (status, Stop, direct input) ----------

    /** Status update while a task runs; makes sure the island is visible. */
    void showOverlay(final String status) {
        if (!Island.visible()) Island.show(this);
        Island.runStatus(status);
    }

    /** Task finished: island goes back to idle, or hides if the user switched it off. */
    void hideOverlay() {
        if (Store.islandOn(this)) Island.runFinished();
        else Island.hide();
    }

    /** Yes/no question shown on the island. */
    boolean confirm(final String question) {
        if (!Island.visible()) Island.show(this);
        return Island.confirm(question);
    }
}
