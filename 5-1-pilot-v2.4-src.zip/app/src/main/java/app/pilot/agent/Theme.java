package app.pilot.agent;

import android.content.Context;

/**
 * Color themes. Flat, warm neutrals only: no blue, no purple, no glow.
 * "Liquid glass" keeps the charcoal app but renders the floating surfaces
 * (island pill, command panel) as frosted translucent glass.
 */
final class Theme {
    static final String CHARCOAL = "charcoal";
    static final String PORCELAIN = "porcelain";
    static final String GLASS = "glass";

    final String id;
    final String name;
    final int bg, surface, surface2, stroke, text, dark, muted, ok, warn;
    final boolean glass;

    private Theme(String id, String name, int bg, int surface, int surface2, int stroke,
                  int text, int dark, int muted, int ok, int warn, boolean glass) {
        this.id = id; this.name = name;
        this.bg = bg; this.surface = surface; this.surface2 = surface2; this.stroke = stroke;
        this.text = text; this.dark = dark; this.muted = muted; this.ok = ok; this.warn = warn;
        this.glass = glass;
    }

    static final Theme[] ALL = {
            new Theme(CHARCOAL, "Charcoal",
                    0xFF0B0B0C, 0xFF161617, 0xFF1F1F21, 0xFF2A2A2D,
                    0xFFF4F2EE, 0xFF0B0B0C, 0xFF8C8A85, 0xFF5FBF8A, 0xFFE0A458, false),
            new Theme(PORCELAIN, "Porcelain",
                    0xFFF1EEE7, 0xFFFAF8F3, 0xFFE9E5DB, 0xFFD8D2C4,
                    0xFF1C1A17, 0xFFF4F2EE, 0xFF6F6A5E, 0xFF3E9C66, 0xFFC07F3A, false),
            new Theme(GLASS, "Liquid glass",
                    0xFF0B0B0C, 0xFF161617, 0xFF1F1F21, 0xFF2A2A2D,
                    0xFFF4F2EE, 0xFF0B0B0C, 0xFF9B9890, 0xFF5FBF8A, 0xFFE0A458, true),
    };

    // frosted glass surface colors (used only when glass == true)
    static final int GLASS_TOP = 0x3DFFFFFF, GLASS_BOTTOM = 0x1AFFFFFF, GLASS_STROKE = 0x42FFFFFF;
    static final int GLASS_FIELD = 0x24FFFFFF;

    static Theme get(Context c) {
        String id = Store.theme(c);
        for (Theme t : ALL) if (t.id.equals(id)) return t;
        return ALL[0];
    }
}
