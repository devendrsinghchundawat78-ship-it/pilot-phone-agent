package app.pilot.agent;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.os.Handler;
import android.os.Looper;
import android.view.View;

/**
 * Pilot's little blob companion, drawn fully in code (no assets).
 * Flat design, off-white blob on charcoal. States: idle (blinks, sleeps after
 * a while), working (bobs, eyes wander), confirm (amber ! badge), finished
 * (happy eyes, green check badge). Original character, our own silhouette.
 */
public class MascotView extends View {
    public static final int IDLE = 0, WORKING = 1, CONFIRM = 2, FINISHED = 3;

    private static final int BODY = 0xFFF4F2EE;
    private static final int INK = 0xFF161617;
    private static final int AMBER = 0xFFE0A458;
    private static final int GREEN = 0xFF7BC47F;
    private static final int BLUSH = 0x2EC97B6B;

    private static final long SLEEP_AFTER_MS = 90000;

    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Handler h = new Handler(Looper.getMainLooper());
    private int bodyColor = BODY;
    private int inkColor = INK;
    private int state = IDLE;
    private long stateSetAt = System.currentTimeMillis();

    private final Runnable tick = new Runnable() {
        @Override public void run() {
            invalidate();
            h.postDelayed(this, 120);
        }
    };

    public MascotView(Context c) { super(c); }

    /** Theme colors: blob body and the ink used for eyes, mouth and badge glyphs. */
    public void setColors(int body, int ink) {
        bodyColor = body;
        inkColor = ink;
        invalidate();
    }

    public void setState(int s) {
        if (s != state) {
            state = s;
            stateSetAt = System.currentTimeMillis();
            invalidate();
        }
    }

    @Override protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        h.removeCallbacks(tick);
        h.post(tick);
    }

    @Override protected void onDetachedFromWindow() {
        h.removeCallbacks(tick);
        super.onDetachedFromWindow();
    }

    @Override protected void onDraw(Canvas c) {
        float w = getWidth(), hh = getHeight();
        float t = (System.currentTimeMillis() - stateSetAt) / 1000f;
        float wall = System.currentTimeMillis() / 1000f;
        boolean sleeping = state == IDLE && (System.currentTimeMillis() - stateSetAt) > SLEEP_AFTER_MS;

        // body: our blob - wider than tall, small bump on the top-left
        float bw = w * 0.86f, bh = hh * 0.72f;
        float bob = state == WORKING ? (float) Math.sin(wall * 5) * hh * 0.035f : 0;
        float cx = w / 2f, cy = hh / 2f + hh * 0.06f + bob;
        RectF body = new RectF(cx - bw / 2, cy - bh / 2, cx + bw / 2, cy + bh / 2);
        p.setStyle(Paint.Style.FILL);
        p.setColor(bodyColor);
        Path blob = new Path();
        blob.addRoundRect(body, bh * 0.52f, bh * 0.52f, Path.Direction.CW);
        c.drawPath(blob, p);
        c.drawCircle(body.left + bw * 0.20f, body.top + bh * 0.04f, bh * 0.15f, p);

        // eyes
        float eyeY = cy - bh * 0.08f;
        float eyeDx = bw * 0.17f;
        float wander = state == WORKING ? (float) Math.sin(wall * 2.2) * bw * 0.03f : 0;
        boolean blink = state == IDLE && !sleeping && (wall % 3.7f) < 0.12f;
        p.setColor(inkColor);
        if (state == FINISHED) {
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(hh * 0.045f);
            p.setStrokeCap(Paint.Cap.ROUND);
            for (int sgn = -1; sgn <= 1; sgn += 2) {
                float ex = cx + sgn * eyeDx;
                c.drawArc(new RectF(ex - hh * 0.055f, eyeY - hh * 0.05f, ex + hh * 0.055f, eyeY + hh * 0.06f), 200, 140, false, p);
            }
            p.setStyle(Paint.Style.FILL);
        } else if (sleeping) {
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(hh * 0.04f);
            p.setStrokeCap(Paint.Cap.ROUND);
            c.drawLine(cx - eyeDx - hh * 0.05f, eyeY, cx - eyeDx + hh * 0.05f, eyeY, p);
            c.drawLine(cx + eyeDx - hh * 0.05f, eyeY, cx + eyeDx + hh * 0.05f, eyeY, p);
            p.setStyle(Paint.Style.FILL);
        } else {
            float eh = blink ? hh * 0.018f : hh * 0.085f;
            c.drawOval(new RectF(cx - eyeDx - hh * 0.032f + wander, eyeY - eh / 2, cx - eyeDx + hh * 0.032f + wander, eyeY + eh / 2), p);
            c.drawOval(new RectF(cx + eyeDx - hh * 0.032f + wander, eyeY - eh / 2, cx + eyeDx + hh * 0.032f + wander, eyeY + eh / 2), p);
        }

        // blush dashes
        p.setColor(BLUSH);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(hh * 0.028f);
        c.drawLine(cx - bw * 0.30f, cy + bh * 0.10f, cx - bw * 0.22f, cy + bh * 0.10f, p);
        c.drawLine(cx + bw * 0.22f, cy + bh * 0.10f, cx + bw * 0.30f, cy + bh * 0.10f, p);
        p.setStyle(Paint.Style.FILL);

        // mouth
        p.setColor(inkColor);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(hh * 0.032f);
        p.setStrokeCap(Paint.Cap.ROUND);
        float my = cy + bh * 0.17f;
        if (state == FINISHED) {
            c.drawArc(new RectF(cx - hh * 0.06f, my - hh * 0.05f, cx + hh * 0.06f, my + hh * 0.06f), 20, 140, false, p);
        } else if (state == WORKING || sleeping) {
            c.drawCircle(cx, my, hh * 0.024f, p);
        } else {
            c.drawLine(cx - hh * 0.045f, my, cx + hh * 0.045f, my, p);
        }
        p.setStyle(Paint.Style.FILL);

        // badge (confirm / finished)
        if (state == CONFIRM || state == FINISHED) {
            p.setColor(state == CONFIRM ? AMBER : GREEN);
            float br = hh * 0.15f;
            float bx = body.right - br * 0.3f, by = body.top + br * 0.3f;
            c.drawCircle(bx, by, br, p);
            p.setColor(inkColor);
            p.setTextSize(br * 1.5f);
            p.setTextAlign(Paint.Align.CENTER);
            p.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
            Paint.FontMetrics fm = p.getFontMetrics();
            c.drawText(state == CONFIRM ? "!" : "\u2713", bx, by - (fm.ascent + fm.descent) / 2f, p);
            p.setTypeface(android.graphics.Typeface.DEFAULT);
        }
    }
}
