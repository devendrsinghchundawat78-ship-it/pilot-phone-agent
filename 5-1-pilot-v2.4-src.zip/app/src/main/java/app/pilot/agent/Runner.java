package app.pilot.agent;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.regex.Pattern;

/** The think-act loop: plan, read screen, ask AI for one action, do it, repeat. */
final class Runner {
    static final int USER = 0, AGENT = 1, STEP = 2, NOTE = 3;

    static class Entry {
        final int type;
        final String text;
        Entry(int type, String text) { this.type = type; this.text = text; }
    }

    interface Listener { void onChange(); }

    static final List<Entry> log = new ArrayList<>();
    private static final java.util.concurrent.CopyOnWriteArrayList<Listener> listeners =
            new java.util.concurrent.CopyOnWriteArrayList<>();
    static volatile boolean running = false;
    private static volatile boolean stopFlag = false;
    private static final Handler MAIN = new Handler(Looper.getMainLooper());
    private static final int MAX_STEPS = 60;
    private static final int MEMORY_EVERY = 15;
    private static final int MAX_STUCK = 3;

    // Apps we never operate: banking and payment apps.
    private static final Pattern BLOCKED_PKG = Pattern.compile(
            "bank|paisa|phonepe|paytm|npci|upi|razorpay|bhim|mobikwik|freecharge|payu|cred\\.club|paypal|venmo|cashapp|revolut|wallet",
            Pattern.CASE_INSENSITIVE);
    // Taps on things that look like these need a yes from the user first.
    private static final Pattern RISKY = Pattern.compile(
            "\\b(pay|pay now|buy|buy now|purchase|place order|order now|send money|transfer|donate|delete|remove|erase|uninstall|factory reset|sign out|log out|logout|submit|confirm|post|publish|send)\\b",
            Pattern.CASE_INSENSITIVE);

    private static final String SYSTEM =
            "You are Pilot, an assistant that operates an Android phone for the user by reading the screen and doing ONE action at a time.\n"
          + "Each turn you get: the user's goal, a PLAN with numbered subtasks (when available), a MEMORY note (your own earlier summary - trust it over old action lines), what you already did, and the current screen as a numbered list of elements.\n"
          + "Reply with ONE JSON object only, no other text:\n"
          + "{\"thought\":\"very short reason\",\"action\":\"<name>\",\"index\":<number>,\"text\":\"...\",\"direction\":\"up|down\",\"app\":\"...\",\"url\":\"...\",\"seconds\":<number>,\"until\":\"...\",\"subtask\":<number>,\"message\":\"...\"}\n"
          + "Actions:\n"
          + "- open_app: open an app by its name (field app). Use this to start; do not hunt for icons.\n"
          + "- open_url: open a web address in the browser (field url).\n"
          + "- tap: tap element number index.\n"
          + "- type: type text (field text) into element number index (or the focused field if index is missing). Add \"submit\":true to press search/enter after.\n"
          + "- scroll: scroll the screen (direction down moves to later content).\n"
          + "- back, home: system buttons.\n"
          + "- wait: wait seconds (1-30). Add \"until\":\"text\" to stop waiting as soon as text containing it appears on screen (use it for downloads and page loads, e.g. until \"Download complete\").\n"
          + "- downloads: open the browser's downloads list to verify a downloaded file.\n"
          + "- ask: you need info from the user or cannot continue. Put your question in message. Task pauses.\n"
          + "- done: the task is finished. Put a short result for the user in message (answer what was asked, e.g. read out the info).\n"
          + "Rules:\n"
          + "- Use only element numbers from the current screen. Numbers change every turn.\n"
          + "- Work on the CURRENT SUBTASK from the plan. When it is visibly complete on screen, reply with \"subtask\":<next number> while doing its first action.\n"
          + "- Keep going until the goal is truly done. Long tasks may need 20-40 steps; that is normal. Never stop early or call done for partial progress.\n"
          + "- Call done ONLY when the CURRENT SCREEN clearly shows the goal is achieved (the video is playing, the file is in the downloads list, the requested info is on screen and you have read it). If any part is not visibly complete, take the next action instead.\n"
          + "- If a popup, ad or cookie banner blocks the screen, dismiss it first (look for Close, OK, No thanks, Not now or an X button).\n"
          + "- If the screen did not change after your action, try something different - never the exact same thing again.\n"
          + "- Never enter passwords, OTPs, card numbers or PINs. Use ask so the user does it.\n"
          + "- Before anything that spends money, sends a message or post to someone, or deletes data, use ask first unless the user's goal clearly said to do exactly that.\n"
          + "- Never operate banking or payment apps.\n"
          + "- Write messages in the same language the user used.";

    private static final String PLAN_SYSTEM =
            "You are the planner for Pilot, an assistant that operates an Android phone one small action at a time.\n"
          + "Break the user's goal into 3 to 8 short, concrete subtasks in order, each verifiable from the screen.\n"
          + "Reply with ONE JSON object only: {\"steps\":[\"...\",\"...\"]}";

    private static final String MEMORY_SYSTEM =
            "You keep the working memory of Pilot, a phone-control assistant. Rewrite the memory note for the current task:\n"
          + "what is achieved so far, the current screen or app state, and what remains. Under 60 words, plain text.\n"
          + "Reply with ONE JSON object only: {\"memory\":\"...\"}";

    static void addListener(Listener l) { if (l != null) listeners.addIfAbsent(l); }

    static void removeListener(Listener l) { if (l != null) listeners.remove(l); }

    private static void notifyChange() {
        for (Listener l : listeners) MAIN.post(l::onChange);
    }

    static void say(int type, String text) {
        synchronized (log) { log.add(new Entry(type, text)); }
        notifyChange();
    }

    static void clear() {
        synchronized (log) { log.clear(); }
        notifyChange();
    }

    static void stop() {
        stopFlag = true;
    }

    static synchronized void start(final Context ctx, final String goal) {
        if (running) return;
        final Context app = ctx.getApplicationContext();
        running = true;
        stopFlag = false;
        say(USER, goal);
        final int logFrom;
        synchronized (log) { logFrom = log.size() - 1; }
        final String context = recentContext();
        new Thread(() -> {
            try {
                loop(app, goal, context, logFrom);
            } catch (Throwable t) {
                String m = "Stopped: " + (t.getMessage() == null ? t.toString() : t.getMessage());
                say(NOTE, m);
                record(app, goal, "Error", m, 0, logFrom);
            } finally {
                running = false;
                AgentService s = AgentService.inst;
                if (s != null) s.hideOverlay();
                notifyChange();
            }
        }, "pilot-loop").start();
    }

    private static void record(Context app, String goal, String status, String message, int steps, int logFrom) {
        List<String> t = new ArrayList<>();
        synchronized (log) {
            int from = Math.max(0, Math.min(logFrom, log.size()));
            for (int i = from; i < log.size(); i++) {
                Entry e = log.get(i);
                if (e.type == USER) t.add("You: " + e.text);
                else if (e.type == AGENT) t.add("Pilot: " + e.text);
                else if (e.type == STEP) t.add("- " + e.text);
                else t.add(e.text);
            }
        }
        History.add(app, goal, status, message, steps, t);
    }

    private static String recentContext() {
        StringBuilder sb = new StringBuilder();
        synchronized (log) {
            int from = Math.max(0, log.size() - 9); // last few lines before this goal
            for (int i = from; i < log.size() - 1; i++) {
                Entry e = log.get(i);
                if (e.type == USER) sb.append("User earlier said: ").append(e.text).append('\n');
                else if (e.type == AGENT) sb.append("You earlier replied: ").append(e.text).append('\n');
            }
        }
        return sb.toString();
    }

    private static List<String> makePlan(Context app, String goal, String earlier) {
        List<String> out = new ArrayList<>();
        try {
            String u = (earlier == null ? "" : earlier) + "GOAL: " + goal;
            JSONObject o = parse(Llm.ask(app, PLAN_SYSTEM, u));
            JSONArray a = o == null ? null : o.optJSONArray("steps");
            if (a != null) {
                for (int i = 0; i < a.length() && out.size() < 10; i++) {
                    String s = a.optString(i, "").trim();
                    if (!s.isEmpty()) out.add(s);
                }
            }
        } catch (Throwable ignored) { }
        return out;
    }

    private static String updateMemory(Context app, String goal, List<String> plan, int subtask, String memory, List<String> done) {
        try {
            StringBuilder u = new StringBuilder("GOAL: ").append(goal).append('\n');
            if (!plan.isEmpty()) {
                u.append("PLAN:\n");
                for (int i = 0; i < plan.size(); i++)
                    u.append(i + 1).append(". ").append(plan.get(i)).append(i + 1 == subtask ? " (current)" : "").append('\n');
            }
            u.append("OLD MEMORY: ").append(memory.isEmpty() ? "(none)" : memory).append('\n');
            u.append("RECENT ACTIONS:\n");
            int from = Math.max(0, done.size() - 12);
            for (int i = from; i < done.size(); i++) u.append(done.get(i)).append('\n');
            JSONObject o = parse(Llm.ask(app, MEMORY_SYSTEM, u.toString()));
            String m = o == null ? "" : o.optString("memory", "").trim();
            return m.isEmpty() ? memory : m;
        } catch (Throwable ignored) {
            return memory;
        }
    }

    private static void loop(Context app, String goal, String earlier, int logFrom) throws Exception {
        AgentService svc = AgentService.inst;
        if (svc == null) {
            String m = "Accessibility access is off. Turn it on first.";
            say(NOTE, m);
            record(app, goal, "Setup needed", m, 0, logFrom);
            return;
        }
        if (!Store.hasKey(app)) {
            String m = "Add your AI key in Settings first.";
            say(NOTE, m);
            record(app, goal, "Setup needed", m, 0, logFrom);
            return;
        }
        svc.showOverlay("Planning");

        List<String> plan = makePlan(app, goal, earlier);
        if (stopFlag) { say(NOTE, "Stopped."); record(app, goal, "Stopped", "Stopped before starting.", 0, logFrom); return; }
        int subtask = 1;
        String memory = "";
        if (!plan.isEmpty()) {
            StringBuilder p = new StringBuilder("Plan (" + plan.size() + " parts): ");
            for (int i = 0; i < plan.size(); i++) {
                if (i > 0) p.append("  ");
                p.append(i + 1).append(") ").append(plan.get(i));
            }
            String ps = p.toString();
            say(NOTE, ps.length() > 220 ? ps.substring(0, 217) + "..." : ps);
        }

        List<String> done = new ArrayList<>();
        String lastSig = "";
        int repeats = 0;
        int stuckCount = 0;
        boolean stuckHint = false;
        for (int step = 1; step <= MAX_STEPS; step++) {
            if (stopFlag) {
                String m = "Stopped by you.";
                say(NOTE, "Stopped.");
                record(app, goal, "Stopped", m, step - 1, logFrom);
                return;
            }
            svc = AgentService.inst;
            if (svc == null) {
                String m = "Accessibility access was turned off.";
                say(NOTE, m);
                record(app, goal, "Stopped", m, step - 1, logFrom);
                return;
            }

            AgentService.Snap snap = svc.snapshot();
            if (snap.pkg != null && BLOCKED_PKG.matcher(snap.pkg).find()) {
                String m = "This looks like a banking or payment app. I do not operate those. Please do this part yourself.";
                say(AGENT, m);
                record(app, goal, "Blocked", m, step - 1, logFrom);
                return;
            }
            svc.showOverlay("Step " + step + (plan.isEmpty() ? "" : " - part " + subtask + "/" + plan.size()) + " - thinking");

            StringBuilder u = new StringBuilder();
            if (!earlier.isEmpty()) u.append(earlier);
            u.append("GOAL: ").append(goal).append("\n");
            if (!plan.isEmpty()) {
                u.append("PLAN (current subtask: ").append(subtask).append(" of ").append(plan.size()).append("):\n");
                for (int i = 0; i < plan.size(); i++)
                    u.append(i + 1).append(". ").append(plan.get(i)).append(i + 1 == subtask ? " <- current" : "").append('\n');
            }
            if (!memory.isEmpty()) u.append("MEMORY: ").append(memory).append('\n');
            if (stuckHint) {
                u.append("STUCK RECOVERY: your last action repeated with no change. Do NOT repeat it. Try a different route: scroll, go back, dismiss a popup or banner, or use another element.\n");
                stuckHint = false;
            }
            u.append("DONE SO FAR:\n");
            if (done.isEmpty()) u.append("(nothing yet)\n");
            int from = Math.max(0, done.size() - 8);
            for (int i = from; i < done.size(); i++) u.append(i + 1).append(". ").append(done.get(i)).append('\n');
            u.append("CURRENT SCREEN (app: ").append(snap.pkg).append("):\n").append(snap.text);

            String raw = Llm.ask(app, SYSTEM, u.toString());
            if (stopFlag) {
                say(NOTE, "Stopped.");
                record(app, goal, "Stopped", "Stopped by you.", step - 1, logFrom);
                return;
            }
            JSONObject a = parse(raw);
            if (a == null) {
                done.add("(my last reply was not valid, retry)");
                continue;
            }
            String action = a.optString("action", "").toLowerCase(Locale.ROOT);
            String thought = a.optString("thought", "");
            int index = a.optInt("index", -1);
            String text = a.optString("text", "");
            String message = a.optString("message", "");
            int st = a.optInt("subtask", 0);
            if (!plan.isEmpty() && st >= 1 && st <= plan.size()) subtask = st;
            String result;

            String sig = action + "|" + index + "|" + text + "|" + a.optString("app", "") + "|" + a.optString("url", "") + "|" + snap.text.hashCode();
            repeats = sig.equals(lastSig) ? repeats + 1 : 0;
            lastSig = sig;
            if (repeats >= 2) {
                stuckCount++;
                repeats = 0;
                lastSig = "";
                if (stuckCount >= MAX_STUCK) {
                    String m = "I am stuck at the same place even after trying other routes. Tell me what to do next, or rephrase the task.";
                    say(AGENT, m);
                    record(app, goal, "Needs you", m, step - 1, logFrom);
                    return;
                }
                say(NOTE, "No progress - trying a different approach.");
                done.add("(got stuck repeating the same action; must try a different route now)");
                stuckHint = true;
                continue;
            }

            switch (action) {
                case "done": {
                    String m = message.isEmpty() ? "Done." : message;
                    say(AGENT, m);
                    record(app, goal, "Done", m, step - 1, logFrom);
                    return;
                }
                case "ask": {
                    String m = message.isEmpty() ? "I need your help to continue." : message;
                    say(AGENT, m);
                    record(app, goal, "Needs you", m, step - 1, logFrom);
                    return;
                }
                case "open_app": {
                    String name = a.optString("app", text);
                    say(STEP, "Open " + name);
                    result = svc.openApp(name);
                    break;
                }
                case "open_url": {
                    String url = a.optString("url", text);
                    say(STEP, "Open " + shorten(url));
                    result = svc.openUrl(url);
                    break;
                }
                case "downloads": {
                    say(STEP, "Open downloads");
                    result = svc.openDownloads();
                    break;
                }
                case "tap": {
                    String label = svc.labelOf(index);
                    say(STEP, "Tap " + (label.isEmpty() ? "#" + index : label));
                    if (RISKY.matcher(label).find() && !svc.confirm("Tap \"" + label + "\"?")) {
                        String m = "You did not allow that tap, so I stopped.";
                        say(AGENT, m);
                        record(app, goal, "Stopped", m, step - 1, logFrom);
                        return;
                    }
                    result = svc.tap(index);
                    break;
                }
                case "type": {
                    say(STEP, "Type \"" + shorten(text) + "\"");
                    result = svc.type(index, text, a.optBoolean("submit", false));
                    break;
                }
                case "scroll": {
                    String dir = a.optString("direction", "down");
                    say(STEP, "Scroll " + dir);
                    result = svc.scroll(dir);
                    break;
                }
                case "back":
                    say(STEP, "Back");
                    result = svc.global(android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_BACK) ? "ok" : "failed";
                    break;
                case "home":
                    say(STEP, "Home");
                    result = svc.global(android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_HOME) ? "ok" : "failed";
                    break;
                case "wait": {
                    int s = Math.max(1, Math.min(30, a.optInt("seconds", 2)));
                    String until = a.optString("until", "").trim();
                    if (until.isEmpty()) {
                        say(STEP, "Wait " + s + "s");
                        sleep(s * 1000L);
                        result = "waited";
                    } else {
                        say(STEP, "Wait until \"" + shorten(until) + "\"");
                        boolean seen = false;
                        long end = System.currentTimeMillis() + s * 1000L;
                        while (System.currentTimeMillis() < end) {
                            if (stopFlag) break;
                            sleep(1000);
                            AgentService.Snap chk = svc.snapshot();
                            if (chk.text != null && chk.text.toLowerCase(Locale.ROOT)
                                    .contains(until.toLowerCase(Locale.ROOT))) { seen = true; break; }
                        }
                        result = seen ? "saw \"" + until + "\"" : "did not see \"" + until + "\" yet";
                    }
                    break;
                }
                default:
                    result = "unknown action";
            }
            done.add(action + (index >= 0 ? " #" + index : "") + (text.isEmpty() ? "" : " \"" + shorten(text) + "\"")
                    + (a.optString("app", "").isEmpty() ? "" : " " + a.optString("app"))
                    + (a.optString("url", "").isEmpty() ? "" : " " + a.optString("url")) + " -> " + result
                    + (thought.isEmpty() ? "" : " (" + shorten(thought) + ")"));
            sleep(1000);

            if (step % MEMORY_EVERY == 0 && step < MAX_STEPS) {
                svc.showOverlay("Step " + step + " - noting progress");
                memory = updateMemory(app, goal, plan, subtask, memory, done);
            }
        }
        String m = "I used all " + MAX_STEPS + " steps without finishing. Tell me if I should continue.";
        say(AGENT, m);
        record(app, goal, "Did not finish", m, MAX_STEPS, logFrom);
    }

    static JSONObject parse(String raw) {
        if (raw == null) return null;
        String s = raw.trim();
        int i = s.indexOf('{');
        int j = s.lastIndexOf('}');
        if (i < 0 || j <= i) return null;
        try {
            return new JSONObject(s.substring(i, j + 1));
        } catch (Exception e) {
            return null;
        }
    }

    static String shorten(String s) {
        s = s.replace('\n', ' ');
        return s.length() > 60 ? s.substring(0, 57) + "..." : s;
    }

    static void sleep(long ms) {
        try { Thread.sleep(ms); } catch (InterruptedException ignored) { Thread.currentThread().interrupt(); }
    }

    /** No-AI check used to prove the service can really drive other apps. */
    static synchronized void selfTest(Context ctx) {
        if (running) return;
        final Context app = ctx.getApplicationContext();
        running = true;
        stopFlag = false;
        say(USER, "/selftest");
        final int logFrom;
        synchronized (log) { logFrom = log.size() - 1; }
        new Thread(() -> {
            String status = "Done";
            String msg = "Self test finished. I opened Settings, read the screen and scrolled by myself.";
            try {
                AgentService s = AgentService.inst;
                if (s == null) {
                    status = "Setup needed";
                    msg = "Accessibility access is off.";
                    say(NOTE, msg);
                    return;
                }
                s.showOverlay("Self test");
                say(STEP, "Home");
                s.global(android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_HOME);
                sleep(1200);
                say(STEP, "Open Settings");
                say(NOTE, s.openApp("Settings"));
                sleep(2500);
                AgentService.Snap sn = s.snapshot();
                say(STEP, "Read screen of " + sn.pkg);
                int lines = sn.text.split("\n").length;
                say(NOTE, "Saw " + lines + " elements on screen.");
                say(STEP, "Scroll down");
                say(NOTE, s.scroll("down"));
                sleep(1200);
                say(AGENT, msg);
            } catch (Throwable t) {
                status = "Error";
                msg = "Self test failed: " + t;
                say(NOTE, msg);
            } finally {
                record(app, "/selftest", status, msg, 4, logFrom);
                running = false;
                AgentService s = AgentService.inst;
                if (s != null) s.hideOverlay();
                notifyChange();
            }
        }, "pilot-selftest").start();
    }
}
