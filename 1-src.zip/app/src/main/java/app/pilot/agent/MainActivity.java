package app.pilot.agent;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.provider.Settings;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {
    // palette: neutral dark, warm off-white, no glow, no blue or purple
    static final int BG = 0xFF0B0B0C, SURFACE = 0xFF161617, SURFACE2 = 0xFF1F1F21, STROKE = 0xFF2A2A2D;
    static final int TEXT = 0xFFF4F2EE, MUTED = 0xFF8C8A85, OK = 0xFF5FBF8A, WARN = 0xFFE0A458;

    private FrameLayout host;
    private boolean inSettings = false;

    // home views
    private LinearLayout statusCard, chat;
    private ScrollView scroll;
    private EditText input;
    private TextView sendBtn;
    private LinearLayout chips;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        host = new FrameLayout(this);
        host.setBackgroundColor(BG);
        setContentView(host);
        showHome();
    }

    @Override protected void onResume() {
        super.onResume();
        Runner.listener = this::refresh;
        refresh();
    }

    @Override protected void onPause() {
        super.onPause();
        if (Runner.listener != null) Runner.listener = null;
    }

    @Override public void onBackPressed() {
        if (inSettings) showHome(); else super.onBackPressed();
    }

    // ---------------- home ----------------

    private void showHome() {
        inSettings = false;
        host.removeAllViews();
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(44), dp(20), dp(14));

        LinearLayout head = new LinearLayout(this);
        head.setOrientation(LinearLayout.HORIZONTAL);
        head.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout titles = new LinearLayout(this);
        titles.setOrientation(LinearLayout.VERTICAL);
        titles.addView(text("Pilot", 28, TEXT, true));
        titles.addView(text("Tell me what to do on your phone", 13, MUTED, false));
        head.addView(titles, new LinearLayout.LayoutParams(0, -2, 1f));
        TextView set = pill("Settings", false);
        set.setOnClickListener(v -> showSettings());
        head.addView(set);
        root.addView(head);

        statusCard = new LinearLayout(this);
        statusCard.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams sl = new LinearLayout.LayoutParams(-1, -2);
        sl.topMargin = dp(18);
        root.addView(statusCard, sl);

        scroll = new ScrollView(this);
        scroll.setVerticalScrollBarEnabled(false);
        chat = new LinearLayout(this);
        chat.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(chat, new ViewGroup.LayoutParams(-1, -2));
        LinearLayout.LayoutParams cl = new LinearLayout.LayoutParams(-1, 0, 1f);
        cl.topMargin = dp(8);
        root.addView(scroll, cl);

        chips = new LinearLayout(this);
        chips.setOrientation(LinearLayout.VERTICAL);
        root.addView(chips, new LinearLayout.LayoutParams(-1, -2));

        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        input = new EditText(this);
        input.setHint("What should I do?");
        input.setHintTextColor(MUTED);
        input.setTextColor(TEXT);
        input.setTextSize(15);
        input.setMaxLines(4);
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        input.setPadding(dp(18), dp(12), dp(18), dp(12));
        input.setBackground(round(SURFACE, 26, STROKE));
        bar.addView(input, new LinearLayout.LayoutParams(0, -2, 1f));
        sendBtn = new TextView(this);
        sendBtn.setGravity(Gravity.CENTER);
        sendBtn.setTextSize(20);
        sendBtn.setTypeface(null, Typeface.BOLD);
        sendBtn.setOnClickListener(v -> onSend());
        LinearLayout.LayoutParams bl = new LinearLayout.LayoutParams(dp(48), dp(48));
        bl.leftMargin = dp(10);
        bar.addView(sendBtn, bl);
        LinearLayout.LayoutParams barl = new LinearLayout.LayoutParams(-1, -2);
        barl.topMargin = dp(10);
        root.addView(bar, barl);

        host.addView(root, new FrameLayout.LayoutParams(-1, -1));
        refresh();
    }

    private void refresh() {
        if (inSettings || statusCard == null) return;
        boolean acc = AgentService.inst != null;
        boolean key = Store.hasKey(this);
        boolean run = Runner.running;

        // status card
        statusCard.removeAllViews();
        if (acc && key) {
            LinearLayout row = new LinearLayout(this);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.addView(dot(run ? WARN : OK), new LinearLayout.LayoutParams(dp(8), dp(8)));
            TextView t = text(run ? "Working on it..." : "Ready", 13, MUTED, false);
            t.setPadding(dp(8), 0, 0, 0);
            row.addView(t);
            statusCard.addView(row);
        } else {
            LinearLayout card = new LinearLayout(this);
            card.setOrientation(LinearLayout.VERTICAL);
            card.setPadding(dp(16), dp(14), dp(16), dp(14));
            card.setBackground(round(SURFACE, 20, STROKE));
            card.addView(text("Two quick steps to start", 15, TEXT, true));
            card.addView(setupRow("Allow screen control", acc, "Turn on", v ->
                    startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))));
            card.addView(setupRow("Add your free AI key", key, "Add", v -> showSettings()));
            if (!acc) {
                TextView hint = text("In Accessibility, open Pilot and switch it on. If Android says it is restricted: "
                        + "Settings > Apps > Pilot > three dots > Allow restricted settings, then try again.", 12, MUTED, false);
                hint.setPadding(0, dp(8), 0, 0);
                card.addView(hint);
            }
            statusCard.addView(card);
        }

        // chat
        chat.removeAllViews();
        List<Runner.Entry> copy;
        synchronized (Runner.log) { copy = new ArrayList<>(Runner.log); }
        for (Runner.Entry e : copy) chat.addView(bubble(e));
        chips.removeAllViews();
        if (copy.isEmpty() && acc && key) {
            chips.addView(text("Try", 12, MUTED, false));
            chips.addView(chip("Open YouTube and search for lo-fi music"));
            chips.addView(chip("Set an alarm for 6:30 am"));
            chips.addView(chip("Check my battery usage in Settings"));
        }
        scroll.post(() -> scroll.fullScroll(View.FOCUS_DOWN));

        // send button
        if (run) {
            sendBtn.setText("\u25A0");
            sendBtn.setTextSize(16);
            sendBtn.setTextColor(TEXT);
            sendBtn.setBackground(oval(SURFACE2));
        } else {
            sendBtn.setText("\u2191");
            sendBtn.setTextSize(20);
            sendBtn.setTextColor(BG);
            sendBtn.setBackground(oval(TEXT));
        }
    }

    private void onSend() {
        if (Runner.running) { Runner.stop(); return; }
        String goal = input.getText().toString().trim();
        if (goal.isEmpty()) return;
        boolean test = goal.equals("/selftest");
        if (AgentService.inst == null) { startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)); return; }
        if (!test && !Store.hasKey(this)) { showSettings(); return; }
        input.setText("");
        InputMethodManager im = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
        im.hideSoftInputFromWindow(input.getWindowToken(), 0);
        if (test) Runner.selfTest(this); else Runner.start(this, goal);
    }

    private View bubble(Runner.Entry e) {
        LinearLayout wrap = new LinearLayout(this);
        wrap.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams wl = new LinearLayout.LayoutParams(-1, -2);
        wl.topMargin = dp(e.type == Runner.STEP || e.type == Runner.NOTE ? 4 : 12);
        wrap.setLayoutParams(wl);
        TextView t;
        if (e.type == Runner.USER) {
            wrap.setGravity(Gravity.END);
            t = text(e.text, 15, BG, false);
            t.setPadding(dp(16), dp(10), dp(16), dp(10));
            t.setBackground(round(TEXT, 20, TEXT));
            t.setMaxWidth(dp(280));
        } else if (e.type == Runner.AGENT) {
            t = text(e.text, 15, TEXT, false);
            t.setPadding(dp(16), dp(10), dp(16), dp(10));
            t.setBackground(round(SURFACE, 20, STROKE));
            t.setMaxWidth(dp(300));
        } else {
            t = text((e.type == Runner.STEP ? "\u2022  " : "") + e.text, 12, MUTED, false);
            t.setPadding(dp(6), 0, dp(6), 0);
        }
        wrap.addView(t);
        return wrap;
    }

    private View chip(final String s) {
        TextView t = text(s, 14, TEXT, false);
        t.setPadding(dp(16), dp(10), dp(16), dp(10));
        t.setBackground(round(SURFACE, 18, STROKE));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
        lp.topMargin = dp(6);
        t.setLayoutParams(lp);
        t.setOnClickListener(v -> { input.setText(s); input.setSelection(s.length()); });
        return t;
    }

    private View setupRow(String label, boolean done, String action, View.OnClickListener c) {
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(0, dp(10), 0, 0);
        row.addView(dot(done ? OK : WARN), new LinearLayout.LayoutParams(dp(8), dp(8)));
        TextView t = text(label, 14, TEXT, false);
        t.setPadding(dp(10), 0, 0, 0);
        row.addView(t, new LinearLayout.LayoutParams(0, -2, 1f));
        if (!done) {
            TextView b = pill(action, true);
            b.setOnClickListener(c);
            row.addView(b);
        } else {
            row.addView(text("Done", 12, MUTED, false));
        }
        return row;
    }

    // ---------------- settings ----------------

    private void showSettings() {
        inSettings = true;
        host.removeAllViews();
        final LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(44), dp(20), dp(20));

        TextView back = pill("Back", false);
        back.setOnClickListener(v -> showHome());
        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.addView(text("Settings", 28, TEXT, true), new LinearLayout.LayoutParams(0, -2, 1f));
        top.addView(back);
        root.addView(top);

        root.addView(label("AI provider"));
        final LinearLayout seg = new LinearLayout(this);
        seg.setOrientation(LinearLayout.HORIZONTAL);
        root.addView(seg);

        final TextView keyHelp = text("", 12, MUTED, false);
        final EditText key = field("Paste your API key", true);
        final EditText model = field("Model name", false);
        final EditText base = field("API address", false);
        final TextView baseLabel = label("API address");
        final TextView status = text("", 13, MUTED, false);

        final Runnable render = new Runnable() {
            @Override public void run() {
                seg.removeAllViews();
                final boolean g = Store.GEMINI.equals(Store.provider(MainActivity.this));
                seg.addView(segBtn("Google Gemini (free)", g, v -> { Store.setProvider(MainActivity.this, Store.GEMINI); showSettings(); }));
                seg.addView(segBtn("Other (Groq etc.)", !g, v -> { Store.setProvider(MainActivity.this, Store.OTHER); showSettings(); }));
                keyHelp.setText(g ? "Get a free key at aistudio.google.com, then paste it here. The key stays on this phone, encrypted."
                        : "Any OpenAI-compatible service works. Groq has a free tier. The key stays on this phone, encrypted.");
                baseLabel.setVisibility(g ? View.GONE : View.VISIBLE);
                base.setVisibility(g ? View.GONE : View.VISIBLE);
                model.setText(Store.model(MainActivity.this));
                base.setText(Store.baseUrl(MainActivity.this));
                key.setText("");
                key.setHint(Store.hasKey(MainActivity.this) ? "Key saved. Paste a new one to replace" : "Paste your API key");
            }
        };

        root.addView(label("API key"));
        root.addView(key);
        root.addView(keyHelp);
        root.addView(label("Model"));
        root.addView(model);
        root.addView(baseLabel);
        root.addView(base);

        TextView save = pill("Save", true);
        save.setPadding(dp(28), dp(12), dp(28), dp(12));
        save.setOnClickListener(v -> {
            String k = key.getText().toString().trim();
            if (!k.isEmpty()) Store.setKey(this, k);
            if (!model.getText().toString().trim().isEmpty()) Store.setModel(this, model.getText().toString());
            if (base.getVisibility() == View.VISIBLE && !base.getText().toString().trim().isEmpty())
                Store.setBaseUrl(this, base.getText().toString());
            status.setText("Saved.");
            key.setText("");
            key.setHint("Key saved. Paste a new one to replace");
        });
        TextView clear = pill("Remove key", false);
        clear.setOnClickListener(v -> { Store.clearKey(this); status.setText("Key removed."); key.setHint("Paste your API key"); });
        LinearLayout actions = new LinearLayout(this);
        actions.setGravity(Gravity.CENTER_VERTICAL);
        actions.setPadding(0, dp(18), 0, 0);
        actions.addView(save);
        LinearLayout.LayoutParams cl = new LinearLayout.LayoutParams(-2, -2);
        cl.leftMargin = dp(10);
        actions.addView(clear, cl);
        root.addView(actions);
        status.setPadding(0, dp(10), 0, 0);
        root.addView(status);

        TextView note = text("Pilot sends the text on your screen to the AI service you chose, only while a task runs. "
                + "It will not touch banking or payment apps, never types passwords, and asks before anything risky.", 12, MUTED, false);
        note.setPadding(0, dp(24), 0, 0);
        root.addView(note);

        render.run();
        ScrollView sv = new ScrollView(this);
        sv.addView(root);
        host.addView(sv, new FrameLayout.LayoutParams(-1, -1));
    }

    private View segBtn(String s, boolean on, View.OnClickListener c) {
        TextView t = text(s, 13, on ? BG : TEXT, true);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(14), dp(10), dp(14), dp(10));
        t.setBackground(round(on ? TEXT : SURFACE, 18, on ? TEXT : STROKE));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
        lp.rightMargin = dp(8);
        lp.topMargin = dp(8);
        t.setLayoutParams(lp);
        t.setOnClickListener(c);
        return t;
    }

    private TextView label(String s) {
        TextView t = text(s, 12, MUTED, false);
        t.setPadding(0, dp(20), 0, dp(6));
        return t;
    }

    private EditText field(String hint, boolean secret) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setHintTextColor(MUTED);
        e.setTextColor(TEXT);
        e.setTextSize(15);
        e.setSingleLine(true);
        e.setInputType(secret ? (InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD)
                : (InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI));
        e.setPadding(dp(16), dp(12), dp(16), dp(12));
        e.setBackground(round(SURFACE, 16, STROKE));
        return e;
    }

    // ---------------- small helpers ----------------

    private TextView text(String s, int sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(null, Typeface.BOLD);
        return t;
    }

    private TextView pill(String s, boolean primary) {
        TextView t = text(s, 13, primary ? BG : TEXT, true);
        t.setPadding(dp(14), dp(8), dp(14), dp(8));
        t.setBackground(round(primary ? TEXT : SURFACE2, 18, primary ? TEXT : STROKE));
        return t;
    }

    private View dot(int color) {
        View v = new View(this);
        v.setBackground(oval(color));
        return v;
    }

    private GradientDrawable round(int fill, int radiusDp, int stroke) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(fill);
        g.setCornerRadius(dp(radiusDp));
        g.setStroke(dp(1), stroke);
        return g;
    }

    private GradientDrawable oval(int fill) {
        GradientDrawable g = new GradientDrawable();
        g.setShape(GradientDrawable.OVAL);
        g.setColor(fill);
        return g;
    }

    private int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density + 0.5f); }
}
