package app.pilot.agent;

import android.content.Context;
import android.content.SharedPreferences;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Base64;

import java.nio.charset.StandardCharsets;
import java.security.KeyStore;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

/** Settings. The API key is encrypted with a key held in the Android Keystore. */
final class Store {
    static final String GEMINI = "gemini";
    static final String OTHER = "other";
    private static final String ALIAS = "pilot_key_v1";

    private static SharedPreferences p(Context c) {
        return c.getApplicationContext().getSharedPreferences("pilot", Context.MODE_PRIVATE);
    }

    static String provider(Context c) { return p(c).getString("provider", GEMINI); }
    static void setProvider(Context c, String v) { p(c).edit().putString("provider", v).apply(); }

    static String model(Context c) {
        String def = GEMINI.equals(provider(c)) ? "gemini-3.5-flash-lite" : "llama-3.3-70b-versatile";
        return p(c).getString("model_" + provider(c), def);
    }
    static void setModel(Context c, String v) { p(c).edit().putString("model_" + provider(c), v.trim()).apply(); }

    static String baseUrl(Context c) {
        return p(c).getString("base", "https://api.groq.com/openai/v1");
    }
    static void setBaseUrl(Context c, String v) { p(c).edit().putString("base", v.trim()).apply(); }

    static boolean hasKey(Context c) { return getKey(c).length() > 0; }

    static void clearKey(Context c) { p(c).edit().remove("key_" + provider(c)).apply(); }

    static void setKey(Context c, String key) {
        try {
            Cipher ci = Cipher.getInstance("AES/GCM/NoPadding");
            ci.init(Cipher.ENCRYPT_MODE, secret());
            byte[] enc = ci.doFinal(key.trim().getBytes(StandardCharsets.UTF_8));
            String v = Base64.encodeToString(ci.getIV(), Base64.NO_WRAP) + ":" + Base64.encodeToString(enc, Base64.NO_WRAP);
            p(c).edit().putString("key_" + provider(c), v).apply();
        } catch (Exception e) {
            throw new RuntimeException("Could not store key securely", e);
        }
    }

    static String getKey(Context c) {
        try {
            String v = p(c).getString("key_" + provider(c), null);
            if (v == null) return "";
            String[] parts = v.split(":");
            Cipher ci = Cipher.getInstance("AES/GCM/NoPadding");
            ci.init(Cipher.DECRYPT_MODE, secret(), new GCMParameterSpec(128, Base64.decode(parts[0], Base64.NO_WRAP)));
            return new String(ci.doFinal(Base64.decode(parts[1], Base64.NO_WRAP)), StandardCharsets.UTF_8);
        } catch (Exception e) {
            return "";
        }
    }

    private static SecretKey secret() throws Exception {
        KeyStore ks = KeyStore.getInstance("AndroidKeyStore");
        ks.load(null);
        if (ks.containsAlias(ALIAS)) {
            return ((KeyStore.SecretKeyEntry) ks.getEntry(ALIAS, null)).getSecretKey();
        }
        KeyGenerator kg = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore");
        kg.init(new KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .build());
        return kg.generateKey();
    }
}
