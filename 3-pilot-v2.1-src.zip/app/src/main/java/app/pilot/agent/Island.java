package app.pilot.agent;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.os.Looper;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.text.InputType;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

/**
 * The permanent top "island": a small pill that stays on screen while the
 * accessibility service runs. Tap it to open a command box and type or speak
 * the next task without opening the app. Shows live status and Stop while a
 * task runs.
 */
final class Island {
    private static final int BG = 0xF2161617, SURFACE2 = 0xFF1F1F21, STROKE = 0xFF2A2A2D;
    private static final int TEXT = 0xFFF4F2EE, DARK = 0xFF0B0B0C, MUTED = 0xFF8C8A85;
    private static final int OK = 0xFF5FBF8A, WARN = 0xFFE0A458;

    private static AgentService svc;
    private static WindowManager wm;
    private static final Handler MAIN = new Handler(Looper.getMainLooper());

    private static LinearLayout root;      // vertical: pill on top, input card below
    private static WindowManager.LayoutParams lp;
    private static LinearLayout pill;
    private static View dot;
    private static TextView status;
    private static LinearLayout buttons;   // Stop / confirm buttons inside the pill
    private static LinearLayout card;      // expanded input area
    private static EditText input;
    private static ImageView mic;
    private static TextView send;
    private static SpeechRecognizer sr;
    private static boolean listening;
    private static boolean expanded;

    private static final Runner.Listener runnerListener = () -> MAIN.post(Island::refresh);

    static synchronized boolean visible() { return root != null; }
    static synchronized boolean isExpanded() { return expanded; }

    static void show(final AgentService s) {
        MAIN.post(() -> showOnMain(s));
    }

    private static synchronized void showOnMain(AgentService s) {
        if (root != null) return;
        svc = s;
        wm = (WindowManager) s.getSystemService(AgentService.WINDOW_SERVICE);
        buildViews();
        lp = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.CENTER_HORIZONTAL;
        lp.y = dp(36);
        try {
            wm.addView(root, lp);
        } catch (Throwable t) {
            root = null;
            svc = null;
            wm = null;
            return;
        }
        Runner.addListener(runnerListener);
        refresh();
    }

    static void hide() {
        MAIN.post(Island::hideOnMain);
    }

    private static synchronized void hideOnMain() {
        stopVoice();
        Runner.removeListener(runnerListener);
        if (root != null && wm != null) {
            try { wm.removeView(root); } catch (Throwable ignored) { }
        }
        root = null;
        pill = null;
        dot = null;
        status = null;
        buttons = null;
        card = null;
        input = null;
        mic = null;
        send = null;
        lp = null;
        expanded = false;
        svc = null;
        wm = null;
    }

    /** Tile and app toggle: flips the saved preference and applies it. */
    static void toggle(AgentService s) {
        if (visible()) {
            Store.setIsland(s, false);
            hide();
        } else {
            Store.setIsland(s, true);
            show(s);
        }
    }

    /** Status line while a task runs (called from any thread). */
    static void runStatus(final String s) {
        MAIN.post(() -> {
            if (root == null) return;
            setStatus(s);
            refresh();
        });
    }

    /** A task finished: go back to the idle pill, keeping the last reply visible. */
    static void runFinished() {
        MAIN.post(() -> {
            if (root == null) return;
            String last = null;
            synchronized (Runner.log) {
                for (int i = Runner.log.size() - 1; i >= 0; i--) {
                    Runner.Entry e = Runner.log.get(i);
                    if (e.type == Runner.AGENT) { last = e.text; break; }
                }
            }
            setStatus(last != null ? last : "Pilot");
            refresh();
        });
    }

    /** Yes/no question on the island. Blocks the caller (a Runner thread) up to 90s. */
    static boolean confirm(final String question) {
        final CountDownLatch l = new CountDownLatch(1);
        final boolean[] yes = {false};
        MAIN.post(() -> {
            if (root == null || buttons == null) { l.countDown(); return; }
            setStatus(question);
            buttons.removeAllViews();
            buttons.addView(pillButton("Allow", true, v -> { yes[0] = true; l.countDown(); }));
            buttons.addView(pillButton("No", false, v -> l.countDown()));
        });
        try { l.await(90, TimeUnit.SECONDS); } catch (InterruptedException ignored) { }
        MAIN.post(Island::refresh);
        return yes[0];
    }

    // ---------------- views ----------------

    private static void buildViews() {
        root = new LinearLayout(svc);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER_HORIZONTAL);

        pill = new LinearLayout(svc);
        pill.setOrientation(LinearLayout.HORIZONTAL);
        pill.setGravity(Gravity.CENTER_VERTICAL);
        pill.setPadding(dp(14), dp(8), dp(10), dp(8));
        pill.setBackground(round(BG, 22, STROKE));
        pill.setContentDescription("Pilot island");
        pill.setOnClickListener(v -> {
            try {
                android.content.Intent i = new android.content.Intent(svc, CommandActivity.class);
                i.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK);
                svc.startActivity(i);
            } catch (Throwable t) {
                toggleExpanded();
            }
        });

        dot = new View(svc);
        dot.setBackground(oval(OK));
        LinearLayout.LayoutParams dl = new LinearLayout.LayoutParams(dp(8), dp(8));
        pill.addView(dot, dl);

        status = new TextView(svc);
        status.setTextColor(TEXT);
        status.setTextSize(13);
        status.setMaxLines(2);
        status.setEllipsize(TextUtils.TruncateAt.END);
        status.setMaxWidth(dp(160));
        status.setText("Pilot");
        LinearLayout.LayoutParams stl = new LinearLayout.LayoutParams(-2, -2);
        stl.leftMargin = dp(8);
        pill.addView(status, stl);

        buttons = new LinearLayout(svc);
        buttons.setOrientation(LinearLayout.HORIZONTAL);
        pill.addView(buttons);

        root.addView(pill);

        card = new LinearLayout(svc);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(12), dp(10), dp(12), dp(12));
        card.setBackground(round(BG, 22, STROKE));
        card.setVisibility(View.GONE);

        LinearLayout head = new LinearLayout(svc);
        head.setGravity(Gravity.CENTER_VERTICAL);
        TextView title = new TextView(svc);
        title.setText("Pilot");
        title.setTextColor(TEXT);
        title.setTextSize(13);
        title.setTypeface(null, Typeface.BOLD);
        head.addView(title, new LinearLayout.LayoutParams(0, -2, 1f));
        TextView close = new TextView(svc);
        close.setText("\u2715");
        close.setTextColor(MUTED);
        close.setTextSize(15);
        close.setPadding(dp(10), 0, dp(4), 0);
        close.setOnClickListener(v -> collapse());
        head.addView(close);
        card.addView(head);

        LinearLayout row = new LinearLayout(svc);
        row.setGravity(Gravity.CENTER_VERTICAL);

        input = new EditText(svc);
        input.setHint("Type or speak a task");
        input.setHintTextColor(MUTED);
        input.setTextColor(TEXT);
        input.setTextSize(14);
        input.setSingleLine(true);
        input.setImeOptions(EditorInfo.IME_ACTION_SEND);
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        input.setPadding(dp(14), 0, dp(14), 0);
        input.setBackground(round(SURFACE2, 20, STROKE));
        input.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_SEND
                    || (event != null && event.getKeyCode() == KeyEvent.KEYCODE_ENTER)) {
                send();
                return true;
            }
            return false;
        });
        row.addView(input, new LinearLayout.LayoutParams(0, dp(42), 1f));

        mic = new ImageView(svc);
        mic.setImageResource(R.drawable.ic_mic);
        mic.setColorFilter(TEXT);
        mic.setScaleType(ImageView.ScaleType.CENTER);
        mic.setBackground(oval(SURFACE2));
        mic.setContentDescription("Speak");
        mic.setOnClickListener(v -> onMic());
        LinearLayout.LayoutParams ml = new LinearLayout.LayoutParams(dp(42), dp(42));
        ml.leftMargin = dp(8);
        row.addView(mic, ml);

        send = new TextView(svc);
        send.setGravity(Gravity.CENTER);
        send.setTypeface(null, Typeface.BOLD);
        send.setOnClickListener(v -> send());
        LinearLayout.LayoutParams sl = new LinearLayout.LayoutParams(dp(42), dp(42));
        sl.leftMargin = dp(8);
        row.addView(send, sl);

        LinearLayout.LayoutParams rl = new LinearLayout.LayoutParams(-1, -2);
        rl.topMargin = dp(8);
        card.addView(row, rl);

        int w = Math.min(dp(380), svc.getResources().getDisplayMetrics().widthPixels - dp(24));
        LinearLayout.LayoutParams cl = new LinearLayout.LayoutParams(w, -2);
        cl.topMargin = dp(8);
        root.addView(card, cl);

        refresh();
    }

    private static TextView pillButton(String label, boolean primary, View.OnClickListener c) {
        TextView b = new TextView(svc);
        b.setText(label);
        b.setTextSize(12);
        b.setTypeface(null, Typeface.BOLD);
        b.setPadding(dp(12), dp(6), dp(12), dp(6));
        b.setTextColor(primary ? DARK : TEXT);
        b.setBackground(round(primary ? TEXT : SURFACE2, 14, primary ? TEXT : SURFACE2));
        b.setOnClickListener(c);
        LinearLayout.LayoutParams bl = new LinearLayout.LayoutParams(-2, -2);
        bl.leftMargin = dp(8);
        b.setLayoutParams(bl);
        return b;
    }

    // ---------------- expand / collapse ----------------

    private static void toggleExpanded() {
        if (expanded) collapse(); else expand();
    }

    private static void expand() {
        if (root == null || expanded) return;
        expanded = true;
        card.setVisibility(View.VISIBLE);
        lp.flags = WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL;
        try { wm.updateViewLayout(root, lp); } catch (Throwable ignored) { }
        input.requestFocus();
        input.postDelayed(() -> {
            if (input == null || svc == null) return;
            InputMethodManager im = (InputMethodManager) svc.getSystemService(AgentService.INPUT_METHOD_SERVICE);
            im.showSoftInput(input, InputMethodManager.SHOW_IMPLICIT);
        }, 150);
        refresh();
    }

    private static void collapse() {
        if (root == null || !expanded) return;
        expanded = false;
        stopVoice();
        if (svc != null && input != null) {
            InputMethodManager im = (InputMethodManager) svc.getSystemService(AgentService.INPUT_METHOD_SERVICE);
            im.hideSoftInputFromWindow(input.getWindowToken(), 0);
        }
        card.setVisibility(View.GONE);
        lp.flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE;
        try { wm.updateViewLayout(root, lp); } catch (Throwable ignored) { }
    }

    // ---------------- sending ----------------

    private static void send() {
        if (svc == null || input == null) return;
        if (Runner.running) { Runner.stop(); return; }
        String goal = input.getText().toString().trim();
        if (goal.isEmpty()) return;
        boolean test = goal.equals("/selftest");
        if (!test && !Store.hasKey(svc)) {
            setStatus("Add your free AI key in the app first");
            openApp(true);
            return;
        }
        input.setText("");
        if (test) Runner.selfTest(svc); else Runner.start(svc, goal);
        collapse();
    }

    private static void openApp(boolean settings) {
        try {
            Intent i = new Intent(svc, MainActivity.class);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            i.putExtra("open_settings", settings);
            svc.startActivity(i);
        } catch (Throwable ignored) { }
    }

    // ---------------- voice ----------------

    private static void onMic() {
        if (svc == null) return;
        if (listening) {
            stopVoice();
            setStatus("Stopped listening");
            refresh();
            return;
        }
        if (svc.checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            setStatus("Allow the microphone in the app, then try again");
            try {
                Intent i = new Intent(svc, MainActivity.class);
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                i.putExtra("request_mic", true);
                svc.startActivity(i);
            } catch (Throwable ignored) { }
            return;
        }
        if (!SpeechRecognizer.isRecognitionAvailable(svc)) {
            setStatus("Voice typing is not available on this phone");
            return;
        }
        startVoice();
    }

    private static void startVoice() {
        stopVoice();
        try {
            sr = SpeechRecognizer.createSpeechRecognizer(svc);
        } catch (Throwable t) {
            setStatus("Voice typing is not available on this phone");
            return;
        }
        sr.setRecognitionListener(new RecognitionListener() {
            @Override public void onReadyForSpeech(android.os.Bundle params) {
                listening = true;
                setStatus("Listening...");
                refresh();
            }
            @Override public void onBeginningOfSpeech() { }
            @Override public void onRmsChanged(float rmsdB) { }
            @Override public void onBufferReceived(byte[] buffer) { }
            @Override public void onEndOfSpeech() {
                listening = false;
                refresh();
            }
            @Override public void onError(int error) {
                listening = false;
                if (error == 7) stopVoice();
                setStatus((error == 6 || error == 7
                        ? "Did not catch that"
                        : "Voice did not work") + " (" + error + "). Tap the mic and try again");
                refresh();
            }
            @Override public void onResults(android.os.Bundle results) {
                listening = false;
                ArrayList<String> out = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                if (out != null && !out.isEmpty() && !out.get(0).trim().isEmpty()) {
                    input.setText(out.get(0).trim());
                    input.setSelection(input.getText().length());
                    send();
                } else {
                    refresh();
                }
            }
            @Override public void onPartialResults(android.os.Bundle partialResults) {
                ArrayList<String> out = partialResults.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                if (out != null && !out.isEmpty() && input != null) {
                    input.setText(out.get(0));
                    input.setSelection(input.getText().length());
                }
            }
            @Override public void onEvent(int eventType, android.os.Bundle params) { }
        });
        Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "hi-IN")
                .putExtra(RecognizerIntent.EXTRA_ONLY_RETURN_LANGUAGE_PREFERENCE, "hi-IN")
                .putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                .putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1);
        try {
            sr.startListening(i);
            listening = true;
            setStatus("Listening...");
        } catch (Throwable t) {
            setStatus("Voice did not work. Try again");
        }
        refresh();
    }

    private static void stopVoice() {
        if (sr != null) {
            try { sr.stopListening(); } catch (Throwable ignored) { }
            try { sr.destroy(); } catch (Throwable ignored) { }
            sr = null;
        }
        listening = false;
    }

    // ---------------- state ----------------

    private static void setStatus(String s) {
        if (status != null) status.setText(s);
    }

    private static void refresh() {
        if (root == null || dot == null) return;
        boolean run = Runner.running;
        try { ((GradientDrawable) dot.getBackground()).setColor(run ? WARN : OK); } catch (Throwable ignored) { }
        if (buttons != null) {
            buttons.removeAllViews();
            if (run) buttons.addView(pillButton("Stop", false, v -> Runner.stop()));
        }
        if (send != null) {
            if (run) {
                send.setText("\u25A0");
                send.setTextSize(13);
                send.setTextColor(TEXT);
                send.setBackground(oval(SURFACE2));
                send.setContentDescription("Stop");
            } else {
                send.setText("\u2191");
                send.setTextSize(18);
                send.setTextColor(DARK);
                send.setBackground(oval(TEXT));
                send.setContentDescription("Send");
            }
        }
        if (mic != null) mic.setColorFilter(listening ? WARN : TEXT);
    }

    // ---------------- small helpers ----------------

    private static GradientDrawable round(int fill, int radiusDp, int stroke) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(fill);
        g.setCornerRadius(dp(radiusDp));
        g.setStroke(dp(1), stroke);
        return g;
    }

    private static GradientDrawable oval(int fill) {
        GradientDrawable g = new GradientDrawable();
        g.setShape(GradientDrawable.OVAL);
        g.setColor(fill);
        return g;
    }

    private static int dp(int v) {
        return (int) (v * svc.getResources().getDisplayMetrics().density + 0.5f);
    }
}
